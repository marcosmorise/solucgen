/*
  DiagramPanel.java é parte do programa SolucGen

 (c)Copyright 2005~2016 Marcos Morise.

    SolucGen é um software livre; você pode redistribui-lo e/ou
    modifica-lo dentro dos termos da Licença Pública Geral GNU como
    publicada pela Fundação do Software Livre (FSF); na versão 3 da
    Licença.

    Este programa é distribuido na esperança que possa ser util,
    mas SEM NENHUMA GARANTIA; sem uma garantia implicita de ADEQUAÇÂO
    a qualquer MERCADO ou APLICAÇÃO EM PARTICULAR. Veja a
    Licença Pública Geral GNU para maiores detalhes.

    Você deve ter recebido uma cópia da Licença Pública Geral GNU
    junto com este programa, se não, veja em:
    <http://www.gnu.org/licenses/>
 */
package org.soluc.gen.gui;

import org.soluc.gen.project.Project;
import org.soluc.gen.project.ClassBean;
import org.soluc.gen.project.Attribute;

/**
 *
 * @author marcos morise
 */
public final class DiagramPanel extends javax.swing.JPanel {

    private final org.soluc.gen.gui.Main parent;
    private final int cellHeight = 17;
    private final int frameWidth = cellHeight * 10;
    private Project project;
    private int xMouse, yMouse;
    private Boolean edited = false;
    private String pathFile = "";
    private ClassBean selectedClass;
    //private Property selectedProperty;

    /**
     * Creates new form ProjectPanel
     *
     * @param parent
     */
    public DiagramPanel(org.soluc.gen.gui.Main parent) {
        super();
        this.parent = parent;
        initComponents();
        dDiagram.setComponentPopupMenu(popupMenu);
    }

    /**
     * @return the project
     */
    public Project getProject() {
        return project;
    }

    /**
     * @return Window parent
     */
    public org.soluc.gen.gui.Main getParentOwner() {
        return parent;
    }

    /**
     * @param project the project to set
     */
    public void setProject(Project project) {
        if (project == null) {
            this.dDiagram.removeAll();
            this.project = null;
        } else {
            if (this.project != project) {
                this.project = project;
                refreshFrames();
                adjustCoordinates();
            }
        }
    }

    /**
     * @return the xMouse
     */
    public int getMouseX() {
        return xMouse;
    }

    /**
     * @param xMouse the xMouse to set
     */
    public void setXMouse(int xMouse) {
        this.xMouse = xMouse;
    }

    /**
     * @return the yMouse
     */
    public int getMouseY() {
        return yMouse;
    }

    /**
     * @param yMouse the yMouse to set
     */
    public void setYMouse(int yMouse) {
        this.yMouse = yMouse;
    }

    /**
     * @return the edited
     */
    public Boolean isEdited() {
        return edited;
    }

    /**
     * @return the edited
     */
    public Boolean getEdited() {
        return edited;
    }

    /**
     * @param edited the edited to set
     */
    public void setEdited(Boolean edited) {
        this.edited = edited;
    }

    /**
     * @return the pathFile
     */
    public String getPathFile() {
        return pathFile;
    }

    /**
     * @param pathFile the pathFile to set
     */
    public void setPathFile(String pathFile) {
        this.pathFile = pathFile;
    }

    /**
     * @return the selectedClass
     */
    public ClassBean getSelectedClass() {
        return selectedClass;
    }

    /**
     * @param selectedClass the selectedClass to set
     */
    public void setSelectedClass(ClassBean selectedClass) {
        this.selectedClass = selectedClass;
    }

    /**
     * @param g
     */
    public void drawLines(java.awt.Graphics g) {
        //background
        g.setFont(new java.awt.Font("Monospaced", java.awt.Font.BOLD, cellHeight / 2));
        g.setColor(java.awt.Color.WHITE);
        g.fillRect(0, 0, this.getWidth(), this.getHeight());

        //relationship lines
        if (this.dDiagram.getAllFrames().length > 0) {
            //pega altura da barra de titulos
            javax.swing.plaf.basic.BasicInternalFrameUI frameUI = (javax.swing.plaf.basic.BasicInternalFrameUI) this.dDiagram.getAllFrames()[0].getUI();
            int titleSize = frameUI.getNorthPane().getPreferredSize().height;
            int x0;
            int y0;
            int x1;
            int y1;

            //Desenha linhas do relacionamento
            for (ClassBean classBean : project.getClasses()) {
                //OBJECT relationship lines
                java.util.List<Attribute> listAttObject = classBean.getAttributes(Attribute.Type.OBJECT);
                for (Attribute att : listAttObject) {
                    org.soluc.gen.project.attribute.Object attObject = (org.soluc.gen.project.attribute.Object) att;
                    ClassBean classRef = attObject.getClassRef();
                    Attribute attLookUp = attObject.getAttribLookUp();
                    if (classRef != null) {
                        x0 = classBean.getX();
                        x1 = classRef.getX();
                        y0 = classBean.getY() + (classBean.getAttributes().indexOf(att) + 1) * 17 + titleSize;
                        y1 = classRef.getY() + (classRef.getAttributes().indexOf(attLookUp) + 1) * 17 + titleSize;
                        int heightX0 = cellHeight;
                        int heightX1 = cellHeight;
                        if (x0 + frameWidth / 2 < x1) {
                            x0 = x0 + frameWidth;
                            heightX0 = heightX0 * -1;
                        } else {
                            if (x1 + frameWidth / 2 < x0) {
                                x1 = x1 + frameWidth;
                                heightX1 = heightX1 * -1;
                            }
                        }
                        g.setColor(java.awt.Color.BLACK);
                        g.drawLine(x0 - heightX0, y0, x0, y0);
                        g.drawLine(x0 - heightX0, y0, x1 - heightX1, y1);
                        g.drawLine(x1 - heightX1, y1, x1, y1);
                        g.setColor(java.awt.Color.WHITE);
                        g.fillOval(x0 + ((classBean.getX() + frameWidth / 2) < x1 ? 0 : -heightX0 / 2), y0 - cellHeight / 4, cellHeight / 2, cellHeight / 2);
                        g.setColor(java.awt.Color.BLACK);
                        g.drawOval(x0 + ((classBean.getX() + frameWidth / 2) < x1 ? 0 : -heightX0 / 2), y0 - cellHeight / 4, cellHeight / 2, cellHeight / 2);
                        g.drawString("*", x0 - heightX0 / 2, y0 - cellHeight / 3);
                        g.drawString("1", x1 - heightX1 / 2, y1 - cellHeight / 3);
                    }
                }

                //OBJECT LIST relationship lines
                java.util.List<Attribute> listAttObjectList = classBean.getAttributes(Attribute.Type.LIST);
                for (Attribute att : listAttObjectList) {
                    org.soluc.gen.project.attribute.List attList = (org.soluc.gen.project.attribute.List) att;
                    ClassBean classRef = attList.getClassRef();
                    if (classRef != null) {
                        x0 = classBean.getX();
                        x1 = classRef.getX();
                        y0 = classBean.getY() + (classBean.getAttributes().indexOf(att) + 1) * 17 + titleSize;
                        y1 = classRef.getY() + titleSize;
                        int heightX0 = cellHeight;
                        int heightX1 = cellHeight;
                        if (x0 + frameWidth / 2 < x1) {
                            x0 = x0 + frameWidth;
                            heightX0 = heightX0 * -1;
                        } else {
                            if (x1 + frameWidth / 2 < x0) {
                                x1 = x1 + frameWidth;
                                heightX1 = heightX1 * -1;
                            }
                        }
                        g.setColor(java.awt.Color.BLACK);
                        g.drawLine(x0 - heightX0, y0, x0, y0);
                        g.drawLine(x0 - heightX0, y0, x1 - heightX1, y1);
                        g.drawLine(x1 - heightX1, y1, x1, y1);
                        g.fillOval(x0 + ((classBean.getX() + frameWidth / 2) < x1 ? 0 : -heightX0 / 2), y0 - cellHeight / 4, cellHeight / 2, cellHeight / 2);
                        g.drawString("1", x0 - heightX0 / 2, y0 - cellHeight / 3);
                        g.drawString("*", x1 - heightX1 / 2, y1 - cellHeight / 3);
                    }
                }
            }
        }
    }

    /**
     * Atualiza frames
     */
    public void refreshFrames() {
        this.dDiagram.removeAll();
        if (project != null) {
            for (ClassBean classBean : project.getClasses()) {
                javax.swing.JInternalFrame frame = new javax.swing.JInternalFrame();
                javax.swing.plaf.basic.BasicInternalFrameUI frameUI = (javax.swing.plaf.basic.BasicInternalFrameUI) frame.getUI();

                frame.setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
                frame.setResizable(false);
                int listSize = classBean.getAttributes().size() + classBean.getMethods().size();
                listSize = (listSize > 0 ? listSize : 1);
                frame.setBounds(classBean.getX(), classBean.getY(), frameWidth, cellHeight * (3 + listSize)+5);
                frame.setLayout(new java.awt.BorderLayout());
                frame.setTitle(classBean.getName());

                if (classBean.getUniqueAttributes().size() > 0) {
                    frame.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/table" + (!project.isClassDependent(classBean) ? ".png" : "_relationship.png")))); // NOI18N
                    frameUI.getNorthPane().setToolTipText(project.getPackage(classBean) + "." + classBean.getName());
                } else {
                    frame.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/table_error.png"))); // NOI18N
                    frameUI.getNorthPane().setToolTipText(project.getPackage(classBean) + "." + classBean.getName() + " - Need a Unique attribute");
                }
                frameUI.getNorthPane().setComponentPopupMenu(popupMenu);
                frame.add(new ClassBeanPanel(this, project, classBean, cellHeight));
                frame.addComponentListener(new java.awt.event.ComponentAdapter() {
                    @Override
                    public void componentMoved(java.awt.event.ComponentEvent evt) {
                        frameComponentMoved(evt);
                    }
                });
                frameUI.getNorthPane().addMouseListener(new java.awt.event.MouseAdapter() {
                    @Override
                    public void mouseReleased(java.awt.event.MouseEvent evt) {
                        frameMouseReleased(evt);
                    }
                });
                frame.setVisible(true);
                dDiagram.add(frame, javax.swing.JLayeredPane.DEFAULT_LAYER);
            }
        }
        boolean isVisible = popupMenu.isVisible();
        popupMenu.setVisible(false);
        mAddClass.setVisible(true);
        mEditClass.setVisible(false);
        mRemClass.setVisible(false);
        popupMenu.setVisible(isVisible);
        repaint();
    }

    /**
     * Ajusta coordenadas dos classBean
     */
    public void adjustCoordinates() {
        int maxX = 0;
        int maxY = 0;
        int maxAtt = 0;

        if (project.getClasses().size() == this.dDiagram.getAllFrames().length) {
            for (ClassBean classBean : project.getClasses()) {
                javax.swing.JInternalFrame frame = getFrame(classBean.getName());
                classBean.setX(frame.getX());
                classBean.setY(frame.getY());
                frame.setLocation(classBean.getX(), classBean.getY());
                if (frame.getX() > maxX) {
                    maxX = frame.getX();
                }
                if (frame.getY() > maxY) {
                    maxY = frame.getY();
                }
                if ((classBean.getAttributes().size() + classBean.getMethods().size()) > maxAtt) {
                    maxAtt = (classBean.getAttributes().size() + classBean.getMethods().size());
                }
            }
            dDiagram.setPreferredSize(new java.awt.Dimension(maxX + (frameWidth * 2), maxY + ((cellHeight * (3 + maxAtt)) * 2)));
            parent.repaint();
        }
    }

    /**
     * Retorna Frame com o Título passado como parâmetro
     */
    private javax.swing.JInternalFrame getFrame(String name) {
        javax.swing.JInternalFrame[] frames = this.dDiagram.getAllFrames();
        int i = 0;
        while (i < frames.length) {
            if (frames[i].getTitle().equals(name)) {
                return frames[i];
            } else {
                i++;
            }
        }
        return null;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        popupMenu = new javax.swing.JPopupMenu();
        mAddClass = new javax.swing.JMenuItem();
        mEditClass = new javax.swing.JMenuItem();
        mRemClass = new javax.swing.JMenuItem();
        sDiagram = new javax.swing.JScrollPane();
        dDiagram = new javax.swing.JDesktopPane() {
            @Override
            public void paintComponent(java.awt.Graphics g) {
                drawLines(g);
            }
        };

        mAddClass.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/table_add.png"))); // NOI18N
        mAddClass.setText("Add class");
        mAddClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mAddClassActionPerformed(evt);
            }
        });
        popupMenu.add(mAddClass);

        mEditClass.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/table_edit.png"))); // NOI18N
        mEditClass.setText("Rename class");
        mEditClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mEditClassActionPerformed(evt);
            }
        });
        popupMenu.add(mEditClass);

        mRemClass.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/table_delete.png"))); // NOI18N
        mRemClass.setText("Remove class");
        mRemClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mRemClassActionPerformed(evt);
            }
        });
        popupMenu.add(mRemClass);

        setLayout(new java.awt.BorderLayout());

        dDiagram.setAutoscrolls(true);
        dDiagram.setDoubleBuffered(true);
        dDiagram.setDragMode(javax.swing.JDesktopPane.OUTLINE_DRAG_MODE);
        dDiagram.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                dDiagramMouseMoved(evt);
            }
        });
        dDiagram.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                dDiagramMouseReleased(evt);
            }
        });
        sDiagram.setViewportView(dDiagram);

        add(sDiagram, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void dDiagramMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dDiagramMouseMoved
        setXMouse(evt.getX());
        setYMouse(evt.getY());
    }//GEN-LAST:event_dDiagramMouseMoved

    private void dDiagramMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dDiagramMouseReleased
        refreshFrames();
    }//GEN-LAST:event_dDiagramMouseReleased

    private void mAddClassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mAddClassActionPerformed
        String name = javax.swing.JOptionPane.showInputDialog(this, "New class name", "New class", javax.swing.JOptionPane.PLAIN_MESSAGE);
        if (name != null && !name.isEmpty() && !Main.isReservedWord(name)) {
            ClassBean classBean = new ClassBean();
            classBean.setName(name);
            classBean.setX(getMouseX());
            classBean.setY(getMouseY());
            project.getClasses().add(classBean);
            refreshFrames();
            setEdited((Boolean) true);
            adjustCoordinates();
        } else {
            javax.swing.JOptionPane.showMessageDialog(this, "Invalid name!", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_mAddClassActionPerformed

    private void mEditClassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mEditClassActionPerformed
        if (selectedClass != null) {
            String name = javax.swing.JOptionPane.showInputDialog("Class name", selectedClass.getName());
            if (name != null && !name.isEmpty() && !Main.isReservedWord(name)) {
                selectedClass.setName(name);
                refreshFrames();
                setEdited((Boolean) true);
            }
        } else {
            javax.swing.JOptionPane.showMessageDialog(this, "Invalid name!", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_mEditClassActionPerformed

    private void mRemClassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mRemClassActionPerformed
        if (selectedClass != null) {
            if (javax.swing.JOptionPane.showConfirmDialog(this, "Would you like remove "+selectedClass.getName()+" class ?", "Remove class", javax.swing.JOptionPane.OK_CANCEL_OPTION) == javax.swing.JOptionPane.OK_OPTION) {
                project.getClasses().remove(selectedClass);
                refreshFrames();
                setEdited((Boolean) true);
            }
        }
    }//GEN-LAST:event_mRemClassActionPerformed

    private void frameComponentMoved(java.awt.event.ComponentEvent evt) {
        this.dDiagram.getSelectedFrame().setLocation((this.dDiagram.getSelectedFrame().getLocation().x / cellHeight) * cellHeight, (this.dDiagram.getSelectedFrame().getLocation().y / cellHeight) * cellHeight);
        setEdited((Boolean) true);
        adjustCoordinates();
        repaint();
    }

    private void frameMouseReleased(java.awt.event.MouseEvent evt) {
        setSelectedClass(project.getClassBean(this.dDiagram.getSelectedFrame().getTitle()));
        boolean isVisible = popupMenu.isVisible();
        popupMenu.setVisible(false);
        mAddClass.setVisible(false);
        mEditClass.setVisible(true);
        mRemClass.setVisible(true);
        popupMenu.setVisible(isVisible);

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane dDiagram;
    private javax.swing.JMenuItem mAddClass;
    private javax.swing.JMenuItem mEditClass;
    private javax.swing.JMenuItem mRemClass;
    private javax.swing.JPopupMenu popupMenu;
    private javax.swing.JScrollPane sDiagram;
    // End of variables declaration//GEN-END:variables

}
