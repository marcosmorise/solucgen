package org.soluc.gen.project.attribute;

/**
 *
 * @author marcos morise
 */
public final class Float extends org.soluc.gen.project.Attribute {

    private java.lang.Boolean indexed = false;
    private java.lang.Float startValue = 0.0f;
    private java.lang.String maskFormat = "#,##0.###";
    private java.lang.Boolean abs = false;

    /**
     * Constructor
     */
    public Float() {
    }

    /**
     * @return the type
     */
    @Override
    public Type getType() {
        return Type.FLOAT;
    }

    /**
     * @return true if return method is Integer or Float || false otherwise
     */
    @Override
    public java.lang.Boolean isNumericReturn() {
        return true;
    }

    /**
     * @return the Indexed
     */
    @Override
    public java.lang.Boolean isIndexed() {
        return indexed;
    }

    /**
     * @return the Indexed
     */
    public java.lang.Boolean getIndexed() {
        return indexed;
    }

    /**
     * @param indexed true is indexed | false isn't indexed
     */
    public void setIndexed(java.lang.Boolean indexed) {
        this.indexed = indexed;
    }

    /**
     * @return the startValue
     */
    public java.lang.Float getStartValue() {
        return startValue;
    }

    /**
     * @return the startValue formatted
     */
    public java.lang.String getStartValueF() {
        return new java.text.DecimalFormat("#,##0.###").format(startValue);
    }

    /**
     * @param startValue the startValue to set
     */
    public void setStartValue(java.lang.Float startValue) {
        this.startValue = startValue;
    }

    /**
     * @param startValue the startValue formatted to set
     */
    public void setStartValueF(java.lang.String startValue) {
        this.startValue = new java.text.DecimalFormat(this.maskFormat).parse(startValue, new java.text.ParsePosition(0)).floatValue();
    }

    /**
     * @return the maskformat
     */
    public java.lang.String getMaskFormat() {
        return maskFormat;
    }

    /**
     * @param maskFormat the maskformat to set
     */
    public void setMaskFormat(java.lang.String maskFormat) {
        this.maskFormat = maskFormat;
    }

    /**
     * @return the abs
     */
    public java.lang.Boolean isAbs() {
        return abs;
    }

    /**
     * @return the abs
     */
    public java.lang.Boolean getAbs() {
        return abs;
    }

    /**
     * @param abs the abs to set
     */
    public void setAbs(java.lang.Boolean abs) {
        this.abs = abs;
    }

    /**
     * @return clone
     */
    @Override
    public Float cloneThis() {
        Float clone = new Float();
        clone.indexed = this.indexed;
        clone.startValue = this.startValue;
        clone.maskFormat = this.maskFormat;
        clone.abs = this.abs;
        return clone;
    }

}
