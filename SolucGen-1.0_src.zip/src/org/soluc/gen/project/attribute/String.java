package org.soluc.gen.project.attribute;

/**
 * @author marcos morise
 */
public final class String extends org.soluc.gen.project.Attribute {

    public static enum Case {
        NONE("-"),
        UPPER("UPPERCASE"),
        LOWER("lowercase"),
        CAMEL("CamelCase");

        public java.lang.String label;

        Case(java.lang.String label) {
            this.label = label;
        }

        public static java.lang.String[] getLabels() {
            java.lang.String[] labels = new java.lang.String[values().length];
            for (int i = 0; i < Case.values().length; i++) {
                labels[i] = Case.values()[i].label;
            }
            return labels;
        }
    }

    private java.lang.Boolean unique = false;
    private java.lang.Boolean indexed = false;
    private java.lang.String startValue = "";
    private java.lang.Integer length = 50;
    private java.lang.String maskFormat = "";
    private Case ulCase = Case.NONE;
    private java.lang.Boolean noAcute = false;
    private java.lang.Boolean trim = true;

    /**
     * Constructor
     */
    public String() {
    }

    /**
     * @return the type
     */
    @Override
    public Type getType() {
        return Type.STRING;
    }

    /**
     * @return if is Unique
     */
    @Override
    public java.lang.Boolean isUnique() {
        return unique;
    }

    /**
     * @return the unique
     */
    public java.lang.Boolean getUnique() {
        return unique;
    }

    /**
     * @param unique the unique to set
     */
    public void setUnique(java.lang.Boolean unique) {
        this.unique = unique;
        if (unique) {
            this.indexed = false;
        }
    }

    /**
     * @return if is Indexed
     */
    @Override
    public java.lang.Boolean isIndexed() {
        return indexed;
    }

    /**
     * @return the indexed
     */
    public java.lang.Boolean getIndexed() {
        return indexed;
    }

    /**
     * @param indexed the indexed to set
     */
    public void setIndexed(java.lang.Boolean indexed) {
        this.indexed = indexed;
        if (indexed) {
            this.unique = false;
        }
    }

    /**
     * @return the startValue
     */
    public java.lang.String getStartValue() {
        return startValue;
    }

    /**
     * @param startValue the startValue to set
     */
    public void setStartValue(java.lang.String startValue) {
        this.startValue = startValue;
    }

    /**
     * @return the length
     */
    public java.lang.Integer getLength() {
        return length;
    }

    /**
     * @param length the length to set
     */
    public void setLength(java.lang.Integer length) {
        this.length = length > 0 ? length : 1;
    }

    /**
     * @param length the length to set
     */
    public void setLength(java.lang.String length) {
        try {
            setLength(java.lang.Integer.parseInt(length));
        } catch (NumberFormatException e) {
            setLength(50);
        }
    }

    /**
     * @return the maskFormat
     */
    public java.lang.String getMaskFormat() {
        return maskFormat;
    }

    /**
     * @param maskFormat the maskFormat to set
     */
    public void setMaskFormat(java.lang.String maskFormat) {
        this.maskFormat = maskFormat.trim();
    }

    /**
     * @return the ulCase
     */
    public Case getUlCase() {
        return ulCase;
    }

    /**
     * @param ulCase the ulCase to set
     */
    public void setUlCase(Case ulCase) {
        this.ulCase = ulCase;
    }
    /**
     * @return the noAcute
     */
    public java.lang.Boolean isNoAcute() {
        return noAcute;
    }

    /**
     * @return the noAcute
     */
    public java.lang.Boolean getNoAcute() {
        return noAcute;
    }

    /**
     * @param noAcute the noAcute to set
     */
    public void setNoAcute(java.lang.Boolean noAcute) {
        this.noAcute = noAcute;
    }

    /**
     * @return the trim
     */
    public java.lang.Boolean isTrim() {
        return trim;
    }

    /**
     * @return the trim
     */
    public java.lang.Boolean getTrim() {
        return trim;
    }

    /**
     * @param trim the trim to set
     */
    public void setTrim(java.lang.Boolean trim) {
        this.trim = trim;
    }

    /**
     * @return clone
     */
    @Override
    public String cloneThis() {
        String clone = new String();
        clone.unique = this.unique;
        clone.indexed = this.indexed;
        clone.startValue = this.startValue;
        clone.length = this.length;
        clone.maskFormat = this.maskFormat;
        clone.ulCase = this.ulCase;
        clone.noAcute = this.noAcute;
        clone.trim = this.trim;
        return clone;
    }
}
