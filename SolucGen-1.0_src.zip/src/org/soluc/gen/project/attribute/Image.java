package org.soluc.gen.project.attribute;

/**
 * 
 * @author marcos morise
 */
public final class Image extends org.soluc.gen.project.Attribute {

    private java.lang.Boolean fixedWidth = true;
    private java.lang.Integer width = 320;

    /**
     * Constructor
     */
    public Image() {
    }
    
    /**
     * @return the type
     */
    @Override
    public Type getType() {
        return Type.IMAGE;
    }

    /**
     * @return the fixedWidth
     */
    public java.lang.Boolean isFixedWidth() {
        return fixedWidth;
    }
    public java.lang.Boolean getFixedWidth() {
        return fixedWidth;
    }

    /**
     * @param fixedWidth the fixedWidth to set
     */
    public void setFixedWidth(java.lang.Boolean fixedWidth) {
        this.fixedWidth = fixedWidth;
    }

    /**
     * @return the width
     */
    public java.lang.Integer getWidth() {
        return width;
    }

    /**
     * @param width the width to set
     */
    public void setWidth(java.lang.Integer width) {
        this.width = width;
    }
    /**
     * @param width the width to set
     */
    public void setWidth(java.lang.String width) {
        this.width = java.lang.Integer.parseInt(width);
    }

    /**
     * @return clone
     */
    @Override
    public Image cloneThis() {
        Image clone = new Image();
        clone.fixedWidth = this.fixedWidth;
        clone.width = this.width;
        return clone;
    }
}
