package org.soluc.gen.project.attribute;

/**
 * 
 * @author marcos morise
 */
public final class Date extends org.soluc.gen.project.Attribute {

    private java.lang.Boolean indexed;
    private java.lang.Boolean useCurrentDate;

    /**
     * Constructor
     */
    public Date() {
        indexed = false;
        useCurrentDate = false;
    }

    /**
     * @return the type
     */
    @Override
    public Type getType() {
        return Type.DATE;
    }

    /**
     * @return the Indexed
     */
    @Override
    public java.lang.Boolean isIndexed() {
        return indexed;
    }
    public java.lang.Boolean getIndexed() {
        return indexed;
    }
    /**
     * @param indexed true is indexed | false isn't indexed
     */
    public void setIndexed(java.lang.Boolean indexed) {
        this.indexed = indexed;
    }

    /**
     * @return the useCurrentDate
     */
    public java.lang.Boolean isUseCurrentDate() {
        return useCurrentDate;
    }
    public java.lang.Boolean getUseCurrentDate() {
        return useCurrentDate;
    }
    /**
     * @param useCurrentDate the useCurrentDate to set
     */
    public void setUseCurrentDate(java.lang.Boolean useCurrentDate) {
        this.useCurrentDate = useCurrentDate;
    }

    /**
     * @return clone
     */
    @Override
    public Date cloneThis() {
        Date clone = new Date();
        clone.setName(this.getName());
        clone.indexed = this.indexed;
        clone.useCurrentDate = this.useCurrentDate;
        return clone;
    }

}
