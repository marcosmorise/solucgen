package org.soluc.gen.project.attribute;

/**
 *
 * @author marcos morise
 */
public final class List extends org.soluc.gen.project.Attribute {

    private org.soluc.gen.project.ClassBean classRef = null;

    /**
     * Construtor
     */
    public List() {
    }

    /**
     * @return the type
     */
    @Override
    public Type getType() {
        return Type.LIST;
    }

    /**
     * @return the classRef
     */
    public org.soluc.gen.project.ClassBean getClassRef() {
        return classRef;
    }

    /**
     * @param classRef the classRef to set
     */
    public void setClassRef(org.soluc.gen.project.ClassBean classRef) {
        this.classRef = classRef;
    }

    /**
     * @return clone
     */
    @Override
    public List cloneThis() {
        List clone = new List();
        clone.classRef = null;
        return clone;
    }
}
