package org.soluc.gen.project.attribute;

/**
 * @author marcos morise
 */
public final class Enum extends org.soluc.gen.project.Attribute {

    private java.lang.Boolean indexed = false;
    private java.lang.String optionsList = "";

    /**
     * Construtor
     */
    public Enum() {
    }

    /**
     * @return the type
     */
    @Override
    public Type getType() {
        return Type.ENUM;
    }

    /**
     * @return true if return method is Integer or Float || false otherwise
     */
    @Override
    public java.lang.Boolean isNumericReturn() {
        return true;
    }

    /**
     * @return if is Indexed
     */
    @Override
    public java.lang.Boolean isIndexed() {
        return indexed;
    }

    /**
     * @return the indexed
     */
    public java.lang.Boolean getIndexed() {
        return indexed;
    }

    /**
     * @param indexed the indexed to set
     */
    public void setIndexed(java.lang.Boolean indexed) {
        this.indexed = indexed;
    }

    /**
     * @return the optionsList
     */
    public java.lang.String getOptionsList() {
        return optionsList;
    }

    /**
     * @param optionsList the optionsList to set
     */
    public void setOptionsList(java.lang.String optionsList) {
        this.optionsList = java.util.regex.Pattern.compile("\\p{InCombiningDiacriticalMarks}+").matcher(java.text.Normalizer.normalize(this.optionsList.trim(), java.text.Normalizer.Form.NFD)).replaceAll("");
        this.optionsList = this.optionsList.replaceAll("[^A-Za-z0-9_]+", "");
        this.optionsList = optionsList.trim().replace(" ", "_");
    }

    /**
     * @return clone
     */
    @Override
    public Enum cloneThis() {
        Enum clone = new Enum();
        clone.indexed = this.indexed;
        clone.optionsList = this.optionsList;
        return clone;
    }

}
