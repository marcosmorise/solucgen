package org.soluc.gen.project.attribute;

/**
 * @author marcos morise
 */
public final class Short extends org.soluc.gen.project.Attribute {

    private java.lang.Boolean indexed = false;
    private java.lang.Short startValue = 0;
    private java.lang.Boolean abs = false;

    /**
     * Construtor
     */
    public Short() {
    }

    /**
     * @return the type
     */
    @Override
    public Type getType() {
        return Type.SHORT;
    }

    /**
     * @return true if return method is Integer or Float || false otherwise
     */
    @Override
    public java.lang.Boolean isNumericReturn() {
        return true;
    }

    /**
     * @return if is Indexed
     */
    @Override
    public java.lang.Boolean isIndexed() {
        return indexed;
    }

    /**
     * @return the indexed
     */
    public java.lang.Boolean getIndexed() {
        return indexed;
    }

    /**
     * @param indexed the indexed to set
     */
    public void setIndexed(java.lang.Boolean indexed) {
        this.indexed = indexed;
    }

    /**
     * @return the startValue
     */
    public java.lang.Short getStartValue() {
        return startValue;
    }

    /**
     * @param startValue the startValue to set
     */
    public void setStartValue(java.lang.Short startValue) {
        this.startValue = startValue;
    }

    /**
     * @param startValue the startValue to set
     */
    public void setStartValue(java.lang.String startValue) {
        try {
            this.startValue = java.lang.Short.parseShort(startValue);
        } catch (NumberFormatException e) {
            this.startValue = 0;
        }
    }

    /**
     * @return the abs
     */
    public java.lang.Boolean isAbs() {
        return abs;
    }

    /**
     * @return the abs
     */
    public java.lang.Boolean getAbs() {
        return abs;
    }

    /**
     * @param abs the abs to set
     */
    public void setAbs(java.lang.Boolean abs) {
        this.abs = abs;
    }

    /**
     * @return clone
     */
    @Override
    public Short cloneThis() {
        Short clone = new Short();
        clone.indexed = this.indexed;
        clone.startValue = this.startValue;
        clone.abs = this.abs;
        return clone;
    }

}
