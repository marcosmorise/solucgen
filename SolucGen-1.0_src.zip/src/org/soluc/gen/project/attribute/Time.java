package org.soluc.gen.project.attribute;

/**
 *
 * @author marcos morise
 */
public final class Time extends org.soluc.gen.project.Attribute {

    private java.lang.Boolean indexed;
    private java.lang.Boolean useCurrentTime;

    /**
     * Constructor
     */
    public Time() {
        indexed = false;
        useCurrentTime = false;
    }

    /**
     * @return the type
     */
    @Override
    public Type getType() {
        return Type.TIME;
    }

    /**
     * @return the Indexed
     */
    @Override
    public java.lang.Boolean isIndexed() {
        return indexed;
    }

    public java.lang.Boolean getIndexed() {
        return indexed;
    }

    /**
     * @param indexed true is indexed | false isn't indexed
     */
    public void setIndexed(java.lang.Boolean indexed) {
        this.indexed = indexed;
    }

    /**
     * @return the useCurrentTime
     */
    public java.lang.Boolean isUseCurrentTime() {
        return useCurrentTime;
    }

    public java.lang.Boolean getUseCurrentTime() {
        return useCurrentTime;
    }

    /**
     * @param useCurrentTime the useCurrentTime to set
     */
    public void setUseCurrentTime(java.lang.Boolean useCurrentTime) {
        this.useCurrentTime = useCurrentTime;
    }

    /**
     * @return clone
     */
    @Override
    public Time cloneThis() {
        Time clone = new Time();
        clone.indexed = this.indexed;
        clone.useCurrentTime = this.useCurrentTime;
        return clone;
    }

}
