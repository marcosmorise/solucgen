package org.soluc.gen.project;

/**
 * @author marcos morise
 * @since 2014-12-18
 */
public class Project {

    private String name = "";
    private java.util.List<ClassBean> classes = new java.util.ArrayList<>();

    /**
     * Constructor
     */
    public Project() {
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        name = java.util.regex.Pattern.compile("\\p{InCombiningDiacriticalMarks}+").matcher(java.text.Normalizer.normalize(name.trim(), java.text.Normalizer.Form.NFD)).replaceAll("");
        name = name.replaceAll("[^A-Za-z0-9_]+", "");
        this.name = name;
    }

    /**
     * @return the beans
     */
    public java.util.List<ClassBean> getClasses() {
        return classes;
    }

    /**
     * @param classes the beans to set
     */
    public void setClasses(java.util.List<ClassBean> classes) {
        this.classes = classes;
    }

    /**
     * @param classBean the bean to move
     */
    public void moveTop(ClassBean classBean) {
        int idx = classes.indexOf(classBean);
        if (idx > 0) {
            classes.remove(idx);
            classes.add(0, classBean);
        }
    }

    /**
     * @param classBean the bean to move
     */
    public void moveBottom(ClassBean classBean) {
        int idx = classes.indexOf(classBean);
        if (idx >= 0) {
            classes.remove(idx);
            classes.add(classBean);
        }
    }

    /**
     * @param classBean the bean to move
     */
    public void moveUp(ClassBean classBean) {
        int idx = classes.indexOf(classBean);
        if (idx > 0) {
            classes.remove(idx);
            classes.add(idx - 1, classBean);
        }
    }

    /**
     * @param classBean the bean to move
     */
    public void moveDown(ClassBean classBean) {
        int idx = classes.indexOf(classBean);
        if (idx >= 0 && idx < classes.size() - 1) {
            classes.remove(idx);
            classes.add(idx + 1, classBean);
        }
    }

    /**
     * @param name
     * @return the class
     */
    public ClassBean getClassBean(String name) {
        ClassBean classBean = null;
        if (name.length() > 0) {
            //Remove acentos
            name = java.util.regex.Pattern.compile("\\p{InCombiningDiacriticalMarks}+").matcher(java.text.Normalizer.normalize(name.trim(), java.text.Normalizer.Form.NFD)).replaceAll("");
            name = name.replaceAll("[^A-Za-z0-9_]+", "");
            //Define a primeira letra maiuscula
            name = name.substring(0, 1).toUpperCase() + name.substring(1, name.length());
            for (ClassBean c : classes) {
                if (c.getName().compareTo(name) == 0) {
                    classBean = c;
                }
            }
        }
        return classBean;
    }

    /**
     * @param name
     * @return if has the class
     */
    public Boolean hasClassBean(String name) {
        Boolean has = false;
        ClassBean classBean = getClassBean(name);
        if (classBean != null) {
            has = true;
        }
        return has;
    }

    /**
     * @param classBean
     * @return classBean package
     */
    public String getPackage(ClassBean classBean) {
        String pkg = classBean.getName().toLowerCase();
        ClassBean classOwner = getClassBeanOwner(classBean);
        if (classOwner != null) {
            pkg = getPackage(classOwner) + "." + pkg;
        }
        return pkg;
    }

    /**
     * @param classBean
     * @return classBean Owner of classBean parameter || null if haven't
     * dependent
     */
    public ClassBean getClassBeanOwner(ClassBean classBean) {
        ClassBean classOwner = null;
        for (ClassBean c : classes) {
            java.util.List<Attribute> attribList = c.getAttributes(Attribute.Type.LIST);
            for (Attribute p : attribList) {
                org.soluc.gen.project.attribute.List al = (org.soluc.gen.project.attribute.List) p;
                if (al.getClassRef() != null && al.getClassRef().getName().compareTo(classBean.getName()) == 0) {
                    classOwner = c;
                }
            }
        }
        return classOwner;
    }

    /**
     * @param classBean
     * @return Dependent Classes List of classBean
     */
    public java.util.List<ClassBean> getDependentClassesOf(ClassBean classBean) {
        java.util.List<ClassBean> dependents = new java.util.ArrayList<>();
        java.util.List<Attribute> attribList = classBean.getAttributes(Attribute.Type.LIST);
        for (Property p : attribList) {
            org.soluc.gen.project.attribute.List al = (org.soluc.gen.project.attribute.List) p;
            if (al.getClassRef() != null) {
                dependents.add(al.getClassRef());
            }
        }
        return dependents;
    }

    /**
     * @param classBean
     * @return if classBean is dependent by another class
     */
    public Boolean isClassDependent(ClassBean classBean) {
        return getClassBeanOwner(classBean) != null;
    }

    /**
     * @return not dependent classes list
     */
    public java.util.List<ClassBean> getNotDependentClasses() {
        java.util.List<ClassBean> notDependentClasses = new java.util.ArrayList<>();
        for (ClassBean c : classes) {
            if (!isClassDependent(c) && c.getUniqueAttributes().size() > 0) {
                notDependentClasses.add(c);
            }
        }
        return notDependentClasses;
    }

    /**
     * @param classBean
     * @return if classBean is referenced by another classes
     */
    public Boolean isClassReferenced(ClassBean classBean) {
        Boolean isReferenced = false;
        for (ClassBean c : classes) {
            for (Attribute p : c.getAttributes()) {
                switch (p.getType()) {
                    case LIST: {
                        org.soluc.gen.project.attribute.List al = (org.soluc.gen.project.attribute.List) p;
                        if (al.getClassRef() != null && al.getClassRef().getName().compareTo(classBean.getName()) == 0) {
                            isReferenced = true;
                        }
                        break;
                    }
                    case OBJECT: {
                        org.soluc.gen.project.attribute.Object ao = (org.soluc.gen.project.attribute.Object) p;
                        if (ao.getClassRef() != null && ao.getAttribLookUp() != null && ao.getClassRef().getName().compareTo(classBean.getName()) == 0) {
                            isReferenced = true;
                        }
                        break;
                    }
                    default:
                        break;
                }
            }
        }
        return isReferenced;
    }

    /**
     * @return the not referenced classes
     */
    public java.util.List<ClassBean> getNotReferencedClasses() {
        java.util.List<ClassBean> notUsedClasses = new java.util.ArrayList<>();
        for (ClassBean c : classes) {
            if (!isClassReferenced(c) && c.getUniqueAttributes().size() > 0) {
                notUsedClasses.add(c);
            }
        }
        return notUsedClasses;
    }

    /**
     * @param classBean
     * @param property
     * @return if property is referenced
     */
    public Boolean isPropertyReferenced(ClassBean classBean, Property property) {
        Boolean isReferenced = false;
        for (ClassBean c : classes) {
            for (Attribute a : c.getAttributes()) {
                switch (a.getType()) {
                    case OBJECT: {
                        org.soluc.gen.project.attribute.Object ao = (org.soluc.gen.project.attribute.Object) a;
                        if (ao.getClassRef() != null && ao.getAttribLookUp() != null
                                && ao.getClassRef().getName().compareTo(classBean.getName()) == 0
                                && ao.getAttribLookUp().getName().compareTo(property.getName()) == 0) {
                            isReferenced = true;
                        }
                        break;
                    }
                }
            }
            for (Method m : c.getMethods()) {
                switch (m.getType()) {
                    case METHOD_LIST_ATT_OPERATION: {
                        org.soluc.gen.project.method.ListAttOperation ao = (org.soluc.gen.project.method.ListAttOperation)m;
                        if (ao.getAttributeList() != null && ao.getAttributeOperation() != null
                                && (ao.getAttributeList().getName().compareTo(property.getName()) == 0
                                || (ao.getAttributeList().getClassRef().getName().compareTo(classBean.getName()) == 0
                                && ao.getAttributeOperation().getName().compareTo(property.getName()) == 0))) {
                            isReferenced = true;
                        }
                        break;
                    }
                    case METHOD_ATT_OPERATION: {
                        org.soluc.gen.project.method.AttOperation ao = (org.soluc.gen.project.method.AttOperation)m;
                        if (ao.getExpression() != null && !ao.getExpression().isEmpty()
                                && ao.getExpression().contains(property)) {
                            isReferenced = true;
                        }
                        break;
                    }
                    default:
                        break;
                }
            }
        }
        return isReferenced;
    }

    /**
     * Save Project to XML file
     *
     * @param name
     * @throws java.io.FileNotFoundException
     */
    public void saveXML(String name) throws java.io.FileNotFoundException {
        try (java.beans.XMLEncoder encoder = new java.beans.XMLEncoder(new java.io.BufferedOutputStream(new java.io.FileOutputStream(name)))) {
            encoder.writeObject(this);
        }
    }

    /**
     * Load Project from XML file
     *
     * @param name
     * @throws java.io.FileNotFoundException
     */
    public void loadXML(String name) throws java.io.FileNotFoundException {
        try (java.beans.XMLDecoder decoder = new java.beans.XMLDecoder(new java.io.BufferedInputStream(new java.io.FileInputStream(name)))) {
            Project project = (Project) decoder.readObject();
            this.setName(project.getName());
            this.setClasses(project.getClasses());
        }
    }
}
