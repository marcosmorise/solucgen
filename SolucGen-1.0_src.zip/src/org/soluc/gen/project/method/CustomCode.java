package org.soluc.gen.project.method;

/**
 *
 * @author marcos morise
 * @since 2016-11-18
 */
public class CustomCode extends org.soluc.gen.project.Method {

    private String returnType;
    private String parameters;
    private String code;

    /**
     * Construtor
     */
    public CustomCode() {
        this.returnType = "void";
        this.parameters = "";
        this.code = "";
    }

    /**
     * @return the type
     */
    @Override
    public Type getType() {
        return Type.METHOD_CUSTOM_CODE;
    }

    /**
     * @return the returnType
     */
    public String getReturnType() {
        return returnType;
    }

    /**
     * @param returnType the returnType to set
     */
    public void setReturnType(String returnType) {
        this.returnType = returnType;
    }

    /**
     * @return the parameters
     */
    public String getParameters() {
        return parameters;
    }

    /**
     * @param parameters the parameters to set
     */
    public void setParameters(String parameters) {
        this.parameters = parameters;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * @return clone
     */
    @Override
    public CustomCode cloneThis() {
        CustomCode clone = new CustomCode();
        clone.returnType = this.returnType;
        clone.parameters = this.parameters;
        clone.code = this.code;
        return clone;
    }
}
