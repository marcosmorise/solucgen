package org.soluc.gen.project.method;

/**
 *
 * @author marcos morise
 * @since 2016-11-18
 */
public class ListAttOperation extends org.soluc.gen.project.Method {

    /**
     * List Operation Types
     */
    public static enum Operation {
        SUM("Sum"),
        AVG("Average"),
        MIN("Minimum"),
        MAX("Maximum");

        public String label;

        Operation(String label) {
            this.label = label;
        }

        public static String[] getLabels() {
            String[] labels = new String[values().length];
            for (int i = 0; i < Operation.values().length; i++) {
                labels[i] = Operation.values()[i].label;
            }
            return labels;
        }

    }

    private org.soluc.gen.project.attribute.List attributeList;
    private org.soluc.gen.project.Property attributeOperation;
    private Operation operation;

    /**
     * Construtor
     */
    public ListAttOperation() {
        this.operation = Operation.SUM;
    }

    /**
     * @return the type
     */
    @Override
    public Type getType() {
        return Type.METHOD_LIST_ATT_OPERATION;
    }

    /**
     * @return the attributeList
     */
    public org.soluc.gen.project.attribute.List getAttributeList() {
        return attributeList;
    }

    /**
     * @param attributeList the attributeList to set
     */
    public void setAttributeList(org.soluc.gen.project.attribute.List attributeList) {
        this.attributeList = attributeList;
    }

    /**
     * @return the attributeOperation
     */
    public org.soluc.gen.project.Property getAttributeOperation() {
        return attributeOperation;
    }

    /**
     * @param attributeOperation the attributeOperation to set
     */
    public void setAttributeOperation(org.soluc.gen.project.Property attributeOperation) {
        this.attributeOperation = attributeOperation;
    }

    /**
     * @return the operation
     */
    public Operation getOperation() {
        return operation;
    }

    /**
     * @param operation the operation to set
     */
    public void setOperation(Operation operation) {
        this.operation = operation;
    }

    /**
     * @return clone
     */
    @Override
    public ListAttOperation cloneThis() {
        ListAttOperation clone = new ListAttOperation();
        return clone;
    }
}
