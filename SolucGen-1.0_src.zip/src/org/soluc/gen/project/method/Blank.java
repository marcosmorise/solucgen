package org.soluc.gen.project.method;

/**
 *
 * @author marcos morise
 * @since 2016-11-18
 */
public class Blank extends org.soluc.gen.project.Method {
    
    /**
     * Construtor
     */
    public Blank() {

    }
    
    /**
     * @return the type
     */
    @Override
    public Type getType() {
        return Type.METHOD_BLANK;
    }
    
    /**
     * @return clone
     */
    @Override
    public Blank cloneThis() {
        Blank clone = new Blank();
        clone.setName(this.getName());
        return clone;
    }
}
