package org.soluc.gen.generator;

/**
 *
 * @author marcos morise
 */
public final class Generator {

    private final org.soluc.gen.project.Project project;
    private final org.soluc.gen.project.ClassBean classBean;

    /**
     * Constructor
     *
     * @param project
     * @param classBean
     */
    public Generator(org.soluc.gen.project.Project project, org.soluc.gen.project.ClassBean classBean) {
        this.project = project;
        this.classBean = classBean;
    }

    /**
     * Code generate
     *
     * @param project
     * @param classBean
     * @param codeTemplate
     * @return
     */
    public static String codeGen(org.soluc.gen.project.Project project, org.soluc.gen.project.ClassBean classBean, String codeTemplate) {
        //get generated code
        String code = new Generator(project, classBean).codeGen(codeTemplate);

        //counter
        String[] codeLines = code.split("\n");
        code = "";
        Integer counter = 0;
        for (String line : codeLines) {
            if (line.contains("<@counter start=")) {
                counter = Integer.parseInt(getTagParam(line, "start"));
                line = line.replaceAll("^\\s+", "").replaceAll("<@counter start=" + counter + "/>", "");
            }
            if (line.contains("<@counter add=")) {
                Integer value = Integer.parseInt(getTagParam(line, "add"));
                counter += value;
                line = line.replaceAll("^\\s+", "").replaceAll("<@counter add=" + value + "/>", "");
            }
            if (line.contains("<@counter/>")) {
                line = line.replaceAll("<@counter/>", "" + counter);
            }
            code += line + "\n";
        }

        //command tags
        code = code.replaceAll("\\ *<@remove length=", "<@remove length=");
        code = code.replaceAll("\n", "");
        code = code.replaceAll("<@/>", "");
        code = code.replaceAll("<@br/>", "\n");
        code = code.replaceAll("<@sp/>", " ");

        //remove
        while (code.contains("<@remove length=")) {
            Integer start = code.indexOf("<@remove length=");
            Integer end = code.indexOf("/>", start);
            Integer length = Integer.parseInt(getTagParam(code.substring(start, end + 2), "length"));
            code = code.substring(0, start - length) + code.substring(end + 2);
        }
     
        return code;
    }

    public static String getTagParam(String tag, String param) {
        try {
            return tag.split(param + "=")[1].split("[/|\\s]")[0];
        } catch (ArrayIndexOutOfBoundsException | NullPointerException ex) {
            return "";
        }
    }

    public static String getTagContent(String code, String tag) {
        try {
            return code.split("<" + tag + ">")[1].split("</" + tag + ">")[0].replaceAll("\\ +$", "");
        } catch (ArrayIndexOutOfBoundsException | NullPointerException ex) {
            return "";
        }
    }

    /**
     * Code generate
     *
     * @param codeTemplate
     * @return generated code
     */
    private String codeGen(String codeTemplate) {
        String code = codeTemplate;
        if (code.contains("@solucgen.code")) {
            code = getTagContent(code, "@solucgen.code");
        }
        code = code.replaceAll("<@project.name/>", project.getName());
        code = code.replaceAll("<@project.nameL/>", project.getName().toLowerCase());
        while (code.contains("<@project.classes>")) {
            code = code.replaceFirst("\\ *(?s)<@project.classes>.*?</@project.classes>", codeProjectClasses(code));
        }

        if (classBean != null) {
            code = code.replaceAll("<@class.package/>", project.getPackage(classBean));
            code = code.replaceAll("<@class.directory/>", project.getPackage(classBean).replace('.', '/'));
            code = code.replaceAll("<@class.name/>", classBean.getName());
            code = code.replaceAll("<@class.nameL/>", classBean.getNameL());
            code = code.replaceAll("<@class.id/>", classBean.getFirstUniqueAttribute().getName());
            code = code.replaceAll("<@class.idU/>", classBean.getFirstUniqueAttribute().getNameU());

            while (code.contains("<@class.isDependent>")) {
                code = code.replaceFirst("\\ *(?s)<@class.isDependent>.*?</@class.isDependent>", codeClassIsDependent(code));
            }
            while (code.contains("<@class.isNotDependent>")) {
                code = code.replaceFirst("\\ *(?s)<@class.isNotDependent>.*?</@class.isNotDependent>", codeClassIsNotDependent(code));
            }
            while (code.contains("<@class.attributes>")) {
                code = code.replaceFirst("\\ *(?s)<@class.attributes>.*?</@class.attributes>", codeClassAttributes(code));
            }
            while (code.contains("<@class.methods>")) {
                code = code.replaceFirst("\\ *(?s)<@class.methods>.*?</@class.methods>", codeClassMethods(code));
            }
        }
        return code;
    }

//******************************************************************************    
//* Project classes code gen
//******************************************************************************
    private String codeProjectClasses(String codeTemplate) {
        String code = "";
        codeTemplate = getTagContent(codeTemplate, "@project.classes");
        for (org.soluc.gen.project.ClassBean bean : project.getClasses()) {
            code += new Generator(project, bean).codeGen(codeTemplate);
            //code += codeGen(project, bean, codeTemplate).replaceAll("\n", "<@br/>");
        }
        return code;
    }

//******************************************************************************    
//* Dependent code gen
//******************************************************************************
    private String codeClassIsNotDependent(String codeTemplate) {
        return !project.isClassDependent(classBean) ? new Generator(project, classBean).codeGen(getTagContent(codeTemplate, "@class.isNotDependent")) : "";
        //return !project.isClassDependent(classBean) ? codeGen(project, classBean, getTagContent(codeTemplate, "@class.isNotDependent")).replaceAll("\n", "<@br/>") : "";
    }

    private String codeClassIsDependent(String codeTemplate) {
        if (project.isClassDependent(classBean)) {
            org.soluc.gen.project.ClassBean classOwner = project.getClassBeanOwner(classBean);
            String code = getTagContent(codeTemplate, "@class.isDependent");
            code = code.replaceAll("<@class.owner.package/>", project.getPackage(classOwner));
            code = code.replaceAll("<@class.owner.directory/>", project.getPackage(classOwner).replace('.', '/'));            
            code = code.replaceAll("<@class.owner.name/>", classOwner.getName());
            code = code.replaceAll("<@class.owner.nameL/>", classOwner.getNameL());
            code = code.replaceAll("<@class.owner.id/>", classOwner.getFirstUniqueAttribute().getName());
            code = code.replaceAll("<@class.owner.idU/>", classOwner.getFirstUniqueAttribute().getNameU());

            java.util.List<org.soluc.gen.project.Attribute> attList = classOwner.getAttributes(org.soluc.gen.project.Attribute.Type.LIST);
            org.soluc.gen.project.attribute.List attOwner = null;
            for (org.soluc.gen.project.Attribute att : attList) {
                org.soluc.gen.project.attribute.List attObj = (org.soluc.gen.project.attribute.List) att;
                if (attObj.getClassRef().getName().compareTo(classBean.getName()) == 0) {
                    attOwner = attObj;
                }
            }
            if (attOwner != null) {
                code = code.replaceAll("<@class.owner.attRef/>", attOwner.getName());
                code = code.replaceAll("<@class.owner.attRefU/>", attOwner.getNameU());
            }
            while (code.contains("<@class.owner.isIdInteger>")) {
                code = code.replaceFirst("\\ *(?s)<@class.owner.isIdInteger>.*?</@class.owner.isIdInteger>", codeClassOwnerIsIdInteger(code));
            }
            while (code.contains("<@class.owner.isIdLong>")) {
                code = code.replaceFirst("\\ *(?s)<@class.owner.isIdLong>.*?</@class.owner.isIdLong>", codeClassOwnerIsIdLong(code));
            }
            while (code.contains("<@class.owner.isIdString>")) {
                code = code.replaceFirst("\\ *(?s)<@class.owner.isIdString>.*?</@class.owner.isIdString>", codeClassOwnerIsIdString(code));
            }

            //return codeGen(project, classBean, code).replaceAll("\n", "<@br/>");
            
            return new Generator(project, classBean).codeGen(code);
        } else {
            return "";
        }
    }

    private String codeClassOwnerIsIdInteger(String codeTemplate) {
        String code = "";
        if (project.getClassBeanOwner(classBean).getFirstUniqueAttribute().getType() == org.soluc.gen.project.Attribute.Type.INTEGER) {
            code = getTagContent(codeTemplate, "@class.owner.isIdInteger");
        }
        return code;
    }

    private String codeClassOwnerIsIdLong(String codeTemplate) {
        String code = "";
        if (project.getClassBeanOwner(classBean).getFirstUniqueAttribute().getType() == org.soluc.gen.project.Attribute.Type.LONG) {
            code = getTagContent(codeTemplate, "@class.owner.isIdLong");
        }
        return code;
    }

    private String codeClassOwnerIsIdString(String codeTemplate) {
        String code = "";
        if (project.getClassBeanOwner(classBean).getFirstUniqueAttribute().getType() == org.soluc.gen.project.Attribute.Type.STRING) {
            code = getTagContent(codeTemplate, "@class.owner.isIdString");
            code = code.replaceAll("<@class.owner.length/>", "" + ((org.soluc.gen.project.attribute.String) project.getClassBeanOwner(classBean).getFirstUniqueAttribute()).getLength());
        }
        return code;
    }

//******************************************************************************    
//* Attributes code gen
//******************************************************************************
    private String codeClassAttributes(String codeTemplate) {
        codeTemplate = getTagContent(codeTemplate, "@class.attributes");
        String code = "";
        for (org.soluc.gen.project.Attribute p : classBean.getAttributes()) {
            switch (p.getType()) {
                case BOOLEAN:
                    code += codeClassAttributeBoolean((org.soluc.gen.project.attribute.Boolean) p, codeTemplate);
                    break;
                case BYTE:
                    code += codeClassAttributeByte((org.soluc.gen.project.attribute.Byte) p, codeTemplate);
                    break;
                case SHORT:
                    code += codeClassAttributeShort((org.soluc.gen.project.attribute.Short) p, codeTemplate);
                    break;
                case INTEGER:
                    code += codeClassAttributeInteger((org.soluc.gen.project.attribute.Integer) p, codeTemplate);
                    break;
                case LONG:
                    code += codeClassAttributeLong((org.soluc.gen.project.attribute.Long) p, codeTemplate);
                    break;
                case FLOAT:
                    code += codeClassAttributeFloat((org.soluc.gen.project.attribute.Float) p, codeTemplate);
                    break;
                case DOUBLE:
                    code += codeClassAttributeDouble((org.soluc.gen.project.attribute.Double) p, codeTemplate);
                    break;
                case STRING:
                    code += codeClassAttributeString((org.soluc.gen.project.attribute.String) p, codeTemplate);
                    break;
                case CHARACTER:
                    code += codeClassAttributeCharacter((org.soluc.gen.project.attribute.Character) p, codeTemplate);
                    break;
                case DATE:
                    code += codeClassAttributeDate((org.soluc.gen.project.attribute.Date) p, codeTemplate);
                    break;
                case TIME:
                    code += codeClassAttributeTime((org.soluc.gen.project.attribute.Time) p, codeTemplate);
                    break;
                case ENUM:
                    code += codeClassAttributeEnum((org.soluc.gen.project.attribute.Enum) p, codeTemplate);
                    break;
                case IMAGE:
                    code += codeClassAttributeImage((org.soluc.gen.project.attribute.Image) p, codeTemplate);
                    break;
                case OBJECT:
                    code += codeClassAttributeObject((org.soluc.gen.project.attribute.Object) p, codeTemplate);
                    break;
                case LIST:
                    code += codeClassAttributeList((org.soluc.gen.project.attribute.List) p, codeTemplate);
                    break;
                default:
                    break;
            }
        }
        return code;
    }

    private String codeClassAttributeDefault(org.soluc.gen.project.Attribute attribute, String codeTemplate) {
        String code = codeTemplate;
        code = code.replaceAll("<@class.attribute.name/>", attribute.getName());
        code = code.replaceAll("<@class.attribute.nameU/>", attribute.getNameU());
        while (code.contains("<@class.attribute.isUnique>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isUnique>.*?</@class.attribute.isUnique>", attribute.isUnique() ? getTagContent(code, "@class.attribute.isUnique") : "");
        }
        while (code.contains("<@class.attribute.isNotUnique>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotUnique>.*?</@class.attribute.isNotUnique>", !attribute.isUnique() ? getTagContent(code, "@class.attribute.isNotUnique") : "");
        }
        while (code.contains("<@class.attribute.isIndexed>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isIndexed>.*?</@class.attribute.isIndexed>", attribute.isIndexed() ? getTagContent(code, "@class.attribute.isIndexed") : "");
        }
        while (code.contains("<@class.attribute.isNotIndexed>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotIndexed>.*?</@class.attribute.isNotIndexed>", !attribute.isIndexed() ? getTagContent(code, "@class.attribute.isNotIndexed") : "");
        }
        while (code.contains("<@class.attribute.isNumericReturn>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNumericReturn>.*?</@class.attribute.isNumericReturn>", attribute.isNumericReturn() ? getTagContent(code, "@class.attribute.isNumericReturn") : "");
        }
        while (code.contains("<@class.attribute.isNotNumericReturn>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotNumericReturn>.*?</@class.attribute.isNotNumericReturn>", !attribute.isNumericReturn() ? getTagContent(code, "@class.attribute.isNotNumericReturn") : "");
        }
        return code;
    }

    private String codeClassAttributeBoolean(org.soluc.gen.project.attribute.Boolean attribute, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.attribute.boolean");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.attribute.default");
        }
        code = codeClassAttributeDefault(attribute, code);
        code = code.replaceAll("<@class.attribute.startValue/>", "" + attribute.getStartValue());
        return code;
    }

    private String codeClassAttributeByte(org.soluc.gen.project.attribute.Byte attribute, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.attribute.byte");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.attribute.default");
        }
        code = codeClassAttributeDefault(attribute, code);
        code = code.replaceAll("<@class.attribute.startValue/>", "" + attribute.getStartValue());
        while (code.contains("<@class.attribute.isAbs>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isAbs>.*?</@class.attribute.isAbs>", attribute.isAbs() ? getTagContent(code, "@class.attribute.isAbs") : "");
        }
        while (code.contains("<@class.attribute.isNotAbs>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotAbs>.*?</@class.attribute.isNotAbs>", !attribute.isAbs() ? getTagContent(code, "@class.attribute.isNotAbs") : "");
        }
        return code;
    }

    private String codeClassAttributeShort(org.soluc.gen.project.attribute.Short attribute, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.attribute.short");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.attribute.default");
        }
        code = codeClassAttributeDefault(attribute, code);
        code = code.replaceAll("<@class.attribute.startValue/>", "" + attribute.getStartValue());
        while (code.contains("<@class.attribute.isAbs>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isAbs>.*?</@class.attribute.isAbs>", attribute.isAbs() ? getTagContent(code, "@class.attribute.isAbs") : "");
        }
        while (code.contains("<@class.attribute.isNotAbs>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotAbs>.*?</@class.attribute.isNotAbs>", !attribute.isAbs() ? getTagContent(code, "@class.attribute.isNotAbs") : "");
        }
        return code;
    }

    private String codeClassAttributeInteger(org.soluc.gen.project.attribute.Integer attribute, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.attribute.integer");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.attribute.default");
        }
        code = codeClassAttributeDefault(attribute, code);
        code = code.replaceAll("<@class.attribute.startValue/>", "" + attribute.getStartValue());
        while (code.contains("<@class.attribute.isId>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isId>.*?</@class.attribute.isId>", attribute.getName().equals(classBean.getFirstUniqueAttribute().getName()) ? getTagContent(code, "@class.attribute.isId") : "");
        }
        while (code.contains("<@class.attribute.isNotId>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotId>.*?</@class.attribute.isNotId>", !attribute.getName().equals(classBean.getFirstUniqueAttribute().getName()) ? getTagContent(code, "@class.attribute.isNotId") : "");
        }
        while (code.contains("<@class.attribute.isAutoIncrement>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isAutoIncrement>.*?</@class.attribute.isAutoIncrement>", attribute.isAutoIncrement() ? getTagContent(code, "@class.attribute.isAutoIncrement") : "");
        }
        while (code.contains("<@class.attribute.isNotAutoIncrement>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotAutoIncrement>.*?</@class.attribute.isNotAutoIncrement>", !attribute.isAutoIncrement() ? getTagContent(code, "@class.attribute.isNotAutoIncrement") : "");
        }
        while (code.contains("<@class.attribute.isUniqueNotAutoIncrement>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isUniqueNotAutoIncrement>.*?</@class.attribute.isUniqueNotAutoIncrement>", attribute.isUnique() && !attribute.isAutoIncrement() ? getTagContent(code, "@class.attribute.isUniqueNotAutoIncrement") : "");
        }
        while (code.contains("<@class.attribute.isAbs>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isAbs>.*?</@class.attribute.isAbs>", attribute.isAbs() ? getTagContent(code, "@class.attribute.isAbs") : "");
        }
        while (code.contains("<@class.attribute.isNotAbs>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotAbs>.*?</@class.attribute.isNotAbs>", !attribute.isAbs() ? getTagContent(code, "@class.attribute.isNotAbs") : "");
        }
        return code;
    }

    private String codeClassAttributeLong(org.soluc.gen.project.attribute.Long attribute, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.attribute.long");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.attribute.default");
        }
        code = codeClassAttributeDefault(attribute, code);
        code = code.replaceAll("<@class.attribute.startValue/>", "" + attribute.getStartValue());
        while (code.contains("<@class.attribute.isId>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isId>.*?</@class.attribute.isId>", attribute.getName().equals(classBean.getFirstUniqueAttribute().getName()) ? getTagContent(code, "@class.attribute.isId") : "");
        }
        while (code.contains("<@class.attribute.isNotId>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotId>.*?</@class.attribute.isNotId>", !attribute.getName().equals(classBean.getFirstUniqueAttribute().getName()) ? getTagContent(code, "@class.attribute.isNotId") : "");
        }
        while (code.contains("<@class.attribute.isAutoIncrement>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isAutoIncrement>.*?</@class.attribute.isAutoIncrement>", attribute.isAutoIncrement() ? getTagContent(code, "@class.attribute.isAutoIncrement") : "");
        }
        while (code.contains("<@class.attribute.isNotAutoIncrement>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotAutoIncrement>.*?</@class.attribute.isNotAutoIncrement>", !attribute.isAutoIncrement() ? getTagContent(code, "@class.attribute.isNotAutoIncrement") : "");
        }
        while (code.contains("<@class.attribute.isUniqueNotAutoIncrement>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isUniqueNotAutoIncrement>.*?</@class.attribute.isUniqueNotAutoIncrement>", attribute.isUnique() && !attribute.isAutoIncrement() ? getTagContent(code, "@class.attribute.isUniqueNotAutoIncrement") : "");
        }
        while (code.contains("<@class.attribute.isAbs>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isAbs>.*?</@class.attribute.isAbs>", attribute.isAbs() ? getTagContent(code, "@class.attribute.isAbs") : "");
        }
        while (code.contains("<@class.attribute.isNotAbs>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotAbs>.*?</@class.attribute.isNotAbs>", !attribute.isAbs() ? getTagContent(code, "@class.attribute.isNotAbs") : "");
        }
        return code;
    }

    private String codeClassAttributeFloat(org.soluc.gen.project.attribute.Float attribute, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.attribute.float");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.attribute.default");
        }
        code = codeClassAttributeDefault(attribute, code);
        code = code.replaceAll("<@class.attribute.startValue/>", "" + attribute.getStartValue());
        code = code.replaceAll("<@class.attribute.maskFormat/>", "" + attribute.getMaskFormat());
        while (code.contains("<@class.attribute.isAbs>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isAbs>.*?</@class.attribute.isAbs>", attribute.isAbs() ? getTagContent(code, "@class.attribute.isAbs") : "");
        }
        while (code.contains("<@class.attribute.isNotAbs>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotAbs>.*?</@class.attribute.isNotAbs>", !attribute.isAbs() ? getTagContent(code, "@class.attribute.isNotAbs") : "");
        }
        return code;
    }

    private String codeClassAttributeDouble(org.soluc.gen.project.attribute.Double attribute, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.attribute.double");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.attribute.default");
        }
        code = codeClassAttributeDefault(attribute, code);
        code = code.replaceAll("<@class.attribute.startValue/>", "" + attribute.getStartValue());
        code = code.replaceAll("<@class.attribute.maskFormat/>", "" + attribute.getMaskFormat());
        while (code.contains("<@class.attribute.isAbs>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isAbs>.*?</@class.attribute.isAbs>", attribute.isAbs() ? getTagContent(code, "@class.attribute.isAbs") : "");
        }
        while (code.contains("<@class.attribute.isNotAbs>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotAbs>.*?</@class.attribute.isNotAbs>", !attribute.isAbs() ? getTagContent(code, "@class.attribute.isNotAbs") : "");
        }
        return code;
    }

    private String codeClassAttributeCharacter(org.soluc.gen.project.attribute.Character attribute, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.attribute.character");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.attribute.default");
        }
        code = codeClassAttributeDefault(attribute, code);
        code = code.replaceAll("<@class.attribute.startValue/>", "" + attribute.getStartValue());
        return code;
    }

    private String codeClassAttributeString(org.soluc.gen.project.attribute.String attribute, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.attribute.string");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.attribute.default");
        }
        code = codeClassAttributeDefault(attribute, code);
        code = code.replaceAll("<@class.attribute.startValue/>", "" + attribute.getStartValue());
        code = code.replaceAll("<@class.attribute.length/>", "" + attribute.getLength());
        code = code.replaceAll("<@class.attribute.maskFormat/>", "" + attribute.getMaskFormat());
        while (code.contains("<@class.attribute.isId>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isId>.*?</@class.attribute.isId>", attribute.getName().equals(classBean.getFirstUniqueAttribute().getName()) ? getTagContent(code, "@class.attribute.isId") : "");
        }
        while (code.contains("<@class.attribute.isNotId>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotId>.*?</@class.attribute.isNotId>", !attribute.getName().equals(classBean.getFirstUniqueAttribute().getName()) ? getTagContent(code, "@class.attribute.isNotId") : "");
        }
        while (code.contains("<@class.attribute.isNotMasked>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotMasked>.*?</@class.attribute.isNotMasked>", attribute.getMaskFormat().isEmpty() ? getTagContent(code, "@class.attribute.isNotMasked") : "");
        }
        while (code.contains("<@class.attribute.isMasked>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isMasked>.*?</@class.attribute.isMasked>", !attribute.getMaskFormat().isEmpty() ? getTagContent(code, "@class.attribute.isMasked") : "");
        }
        while (code.contains("<@class.attribute.isNoAcute>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNoAcute>.*?</@class.attribute.isNoAcute>", attribute.getNoAcute() ? getTagContent(code, "@class.attribute.isNoAcute") : "");
        }
        while (code.contains("<@class.attribute.isAcute>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isAcute>.*?</@class.attribute.isAcute>", !attribute.getNoAcute() ? getTagContent(code, "@class.attribute.isAcute") : "");
        }
        while (code.contains("<@class.attribute.isTrim>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isTrim>.*?</@class.attribute.isTrim>", attribute.isTrim() ? getTagContent(code, "@class.attribute.isTrim") : "");
        }
        while (code.contains("<@class.attribute.isNotTrim>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotTrim>.*?</@class.attribute.isNotTrim>", !attribute.isTrim() ? getTagContent(code, "@class.attribute.isNotTrim") : "");
        }
        while (code.contains("<@class.attribute.isNoneCase>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNoneCase.*?</@class.attribute.isNoneCase>", attribute.getUlCase() == org.soluc.gen.project.attribute.String.Case.NONE ? getTagContent(code, "@class.attribute.isNoneCase") : "");
        }
        while (code.contains("<@class.attribute.isUpperCase>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isUpperCase.*?</@class.attribute.isUpperCase>", attribute.getUlCase() == org.soluc.gen.project.attribute.String.Case.UPPER ? getTagContent(code, "@class.attribute.isUpperCase") : "");
        }
        while (code.contains("<@class.attribute.isLowerCase>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isLowerCase.*?</@class.attribute.isLowerCase>", attribute.getUlCase() == org.soluc.gen.project.attribute.String.Case.LOWER ? getTagContent(code, "@class.attribute.isLowerCase") : "");
        }
        while (code.contains("<@class.attribute.isCamelCase>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isCamelCase.*?</@class.attribute.isCamelCase>", attribute.getUlCase() == org.soluc.gen.project.attribute.String.Case.CAMEL ? getTagContent(code, "@class.attribute.isCamelCase") : "");
        }

        return code;
    }

    private String codeClassAttributeDate(org.soluc.gen.project.attribute.Date attribute, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.attribute.date");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.attribute.default");
        }
        code = codeClassAttributeDefault(attribute, code);
        while (code.contains("<@class.attribute.isUseCurrentDate>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isUseCurrentDate>.*?</@class.attribute.isUseCurrentDate>", attribute.isUseCurrentDate() ? getTagContent(code, "@class.attribute.isUseCurrentDate") : "");
        }
        while (code.contains("<@class.attribute.isNotUseCurrentDate>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotUseCurrentDate>.*?</@class.attribute.isNotUseCurrentDate>", !attribute.isUseCurrentDate() ? getTagContent(code, "@class.attribute.isNotUseCurrentDate") : "");
        }
        return code;
    }

    private String codeClassAttributeTime(org.soluc.gen.project.attribute.Time attribute, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.attribute.time");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.attribute.default");
        }
        code = codeClassAttributeDefault(attribute, code);
        while (code.contains("<@class.attribute.isUseCurrentTime>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isUseCurrentTime>.*?</@class.attribute.isUseCurrentTime>", attribute.isUseCurrentTime() ? getTagContent(code, "@class.attribute.isUseCurrentTime") : "");
        }
        while (code.contains("<@class.attribute.isNotUseCurrentTime>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotUseCurrentTime>.*?</@class.attribute.isNotUseCurrentTime>", !attribute.isUseCurrentTime() ? getTagContent(code, "@class.attribute.isNotUseCurrentTime") : "");
        }
        return code;
    }

    private String codeClassAttributeEnum(org.soluc.gen.project.attribute.Enum attribute, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.attribute.enum");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.attribute.default");
        }
        code = codeClassAttributeDefault(attribute, code);
        while (code.contains("<@class.attribute.enum.options>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.enum.options>.*?</@class.attribute.enum.options>", codeClassAttributeEnumOptions(attribute, code));
        }
        return code;
    }

    private String codeClassAttributeEnumOptions(org.soluc.gen.project.attribute.Enum attribute, String codeTemplate) {
        codeTemplate = getTagContent(codeTemplate, "@class.attribute.enum.options");
        String code = "";
        for (String option : attribute.getOptionsList().split("\n")) {
            code += codeTemplate.replaceAll("<@class.attribute.enum.option/>", option);
        }
        return code;
    }

    private String codeClassAttributeImage(org.soluc.gen.project.attribute.Image attribute, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.attribute.image");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.attribute.default");
        }
        code = codeClassAttributeDefault(attribute, code);
        code = code.replaceAll("<@class.attribute.width/>", "" + attribute.getWidth());
        while (code.contains("<@class.attribute.isFixedWidth>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isFixedWidth>.*?</@class.attribute.isFixedWidth>", attribute.isFixedWidth() ? getTagContent(code, "@class.attribute.isFixedWidth") : "");
        }
        while (code.contains("<@class.attribute.isNotFixedWidth>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotFixedWidth>.*?</@class.attribute.isNotFixedWidth>", !attribute.isFixedWidth() ? getTagContent(code, "@class.attribute.isNotFixedWidth") : "");
        }
        return code;
    }

    private String codeClassAttributeObject(org.soluc.gen.project.attribute.Object attribute, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.attribute.object");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.attribute.default");
        }
        code = codeClassAttributeDefault(attribute, code);
        code = code.replaceAll("<@class.attribute.classRef.name/>", "" + attribute.getClassRef().getName());
        code = code.replaceAll("<@class.attribute.classRef.nameL/>", "" + attribute.getClassRef().getNameL());
        code = code.replaceAll("<@class.attribute.classRef.id/>", "" + attribute.getClassRef().getFirstUniqueAttribute().getName());
        code = code.replaceAll("<@class.attribute.classRef.idU/>", "" + attribute.getClassRef().getFirstUniqueAttribute().getNameU());
        code = code.replaceAll("<@class.attribute.classRef.package/>", "" + project.getPackage(attribute.getClassRef()));
        code = code.replaceAll("<@class.attribute.classRef.directory/>", "" + project.getPackage(attribute.getClassRef()).replace('.', '/'));
        code = code.replaceAll("<@class.attribute.attribLookUp.name/>", "" + attribute.getAttribLookUp().getName());
        code = code.replaceAll("<@class.attribute.attribLookUp.nameU/>", "" + attribute.getAttribLookUp().getNameU());
        code = code.replaceAll("<@class.attribute.classRef.idStringLength/>", !attribute.getClassRef().getFirstUniqueAttribute().isNumericReturn() ? "" + ((org.soluc.gen.project.attribute.String) attribute.getClassRef().getFirstUniqueAttribute()).getLength() : "");

        while (code.contains("<@class.attribute.attribLookUp.isNumericReturn>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.attribLookUp.isNumericReturn>.*?</@class.attribute.attribLookUp.isNumericReturn>", attribute.getAttribLookUp().isNumericReturn() ? getTagContent(code, "@class.attribute.attribLookUp.isNumericReturn") : "");
        }
        while (code.contains("<@class.attribute.attribLookUp.isNotNumericReturn>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.attribLookUp.isNotNumericReturn>.*?</@class.attribute.attribLookUp.isNotNumericReturn>", !attribute.getAttribLookUp().isNumericReturn() ? getTagContent(code, "@class.attribute.attribLookUp.isNotNumericReturn") : "");
        }
        while (code.contains("<@class.attribute.classRef.isIntType>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.classRef.isIntType>.*?</@class.attribute.classRef.isIntType>", attribute.getClassRef().getFirstUniqueAttribute().getType() == org.soluc.gen.project.Attribute.Type.INTEGER ? getTagContent(code, "@class.attribute.classRef.isIntType") : "");
        }
        while (code.contains("<@class.attribute.classRef.isLongType>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.classRef.isLongType>.*?</@class.attribute.classRef.isLongType>", attribute.getClassRef().getFirstUniqueAttribute().getType() == org.soluc.gen.project.Attribute.Type.LONG ? getTagContent(code, "@class.attribute.classRef.isLongType") : "");
        }
        while (code.contains("<@class.attribute.classRef.isStringType>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.classRef.isStringType>.*?</@class.attribute.classRef.isStringType>", attribute.getClassRef().getFirstUniqueAttribute().getType() == org.soluc.gen.project.Attribute.Type.STRING ? getTagContent(code, "@class.attribute.classRef.isStringType") : "");
        }
        while (code.contains("<@class.attribute.isFirstObjectInClass>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isFirstObjectInClass>.*?</@class.attribute.isFirstObjectInClass>", classBean.getAttributes(org.soluc.gen.project.Attribute.Type.OBJECT).get(0).getName().equals(attribute.getName()) ? getTagContent(code, "@class.attribute.isFirstObjectInClass") : "");
        }
        while (code.contains("<@class.attribute.isNotFirstObjectInClass>")) {
            code = code.replaceFirst("\\ *(?s)<@class.attribute.isNotFirstObjectInClass>.*?</@class.attribute.isNotFirstObjectInClass>", !classBean.getAttributes(org.soluc.gen.project.Attribute.Type.OBJECT).get(0).getName().equals(attribute.getName()) ? getTagContent(code, "@class.attribute.isNotFirstObjectInClass") : "");
        }
        return code;
    }

    private String codeClassAttributeList(org.soluc.gen.project.attribute.List attribute, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.attribute.list");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.attribute.default");
        }
        code = codeClassAttributeDefault(attribute, code);
        code = code.replaceAll("<@class.attribute.classRef.name/>", attribute.getClassRef().getName());
        code = code.replaceAll("<@class.attribute.classRef.nameL/>", attribute.getClassRef().getNameL());
        code = code.replaceAll("<@class.attribute.classRef.id/>", "" + attribute.getClassRef().getFirstUniqueAttribute().getName());
        code = code.replaceAll("<@class.attribute.classRef.idU/>", "" + attribute.getClassRef().getFirstUniqueAttribute().getNameU());
        code = code.replaceAll("<@class.attribute.classRef.package/>", project.getPackage(attribute.getClassRef()));
        code = code.replaceAll("<@class.attribute.classRef.directory/>", project.getPackage(attribute.getClassRef()).replace('.', '/'));

        return code;
    }

//******************************************************************************    
//* Methods code gen
//******************************************************************************
    private String codeClassMethods(String codeTemplate) {
        codeTemplate = getTagContent(codeTemplate, "@class.methods");
        String code = "";
        for (org.soluc.gen.project.Method p : classBean.getMethods()) {
            switch (p.getType()) {
                case METHOD_BLANK:
                    code += codeClassMethodBlank((org.soluc.gen.project.method.Blank) p, codeTemplate);
                    break;
                case METHOD_CUSTOM_CODE:
                    code += codeClassMethodCustomCode((org.soluc.gen.project.method.CustomCode) p, codeTemplate);
                    break;
                case METHOD_ATT_OPERATION:
                    code += codeClassMethodAttOperation((org.soluc.gen.project.method.AttOperation) p, codeTemplate);
                    break;
                case METHOD_LIST_ATT_OPERATION:
                    code += codeClassMethodListAttOperation((org.soluc.gen.project.method.ListAttOperation) p, codeTemplate);
                    break;
                default:
                    break;
            }
        }
        return code;
    }

    private String codeClassMethodDefault(org.soluc.gen.project.Method method, String codeTemplate) {
        String code = codeTemplate;
        code = code.replaceAll("<@class.method.name/>", method.getName());
        code = code.replaceAll("<@class.method.nameU/>", method.getNameU());

        return code;
    }

    private String codeClassMethodBlank(org.soluc.gen.project.method.Blank method, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.method.blank");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.method.default");
        }
        code = codeClassMethodDefault(method, code);
        return code;
    }

    private String codeClassMethodCustomCode(org.soluc.gen.project.method.CustomCode method, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.method.customCode");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.method.default");
        }
        code = codeClassMethodDefault(method, code);
        code = code.replaceAll("<@class.method.returnType/>", method.getReturnType());
        code = code.replaceAll("<@class.method.parameters/>", method.getParameters());
        code = code.replaceAll("<@class.method.code/>", method.getCode());
        return code;
    }

    private String codeClassMethodAttOperation(org.soluc.gen.project.method.AttOperation method, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.method.attOperation");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.method.default");
        }
        code = codeClassMethodDefault(method, code);
        code = code.replaceAll("<@class.method.expression/>", method.getExpressionCode());
        return code;
    }

    private String codeClassMethodListAttOperation(org.soluc.gen.project.method.ListAttOperation method, String codeTemplate) {
        String code = getTagContent(codeTemplate, "@class.method.listAttOperation");
        if (code.isEmpty()) {
            code = getTagContent(codeTemplate, "@class.method.default");
        }
        code = codeClassMethodDefault(method, code);
        code = code.replaceAll("<@class.method.attributeList.nameU/>", method.getAttributeList().getNameU());
        code = code.replaceAll("<@class.method.attributeList.name/>", method.getAttributeList().getName());
        code = code.replaceAll("<@class.method.attributeList.classRef.name/>", method.getAttributeList().getClassRef().getName());
        code = code.replaceAll("<@class.method.attributeList.classRef.nameL/>", method.getAttributeList().getClassRef().getNameL());
        code = code.replaceAll("<@class.method.attributeList.classRef.package/>", project.getPackage(method.getAttributeList().getClassRef()));
        code = code.replaceAll("<@class.method.attributeList.classRef.directory/>", project.getPackage(method.getAttributeList().getClassRef()).replace('.', '/'));
        code = code.replaceAll("<@class.method.attributeOperation.name/>", method.getAttributeOperation().getName());
        code = code.replaceAll("<@class.method.attributeOperation.nameU/>", method.getAttributeOperation().getNameU());
        while (code.contains("<@class.method.attributeOperation.isAttribute>")) {
            code = code.replaceFirst("\\ *(?s)<@class.method.attributeOperation.isAttribute>.*?</@class.method.attributeOperation.isAttribute>", method.getAttributeOperation() instanceof org.soluc.gen.project.Attribute ? getTagContent(code, "@class.method.attributeOperation.isAttribute") : "");
        }
        while (code.contains("<@class.method.attributeOperation.isMethod>")) {
            code = code.replaceFirst("\\ *(?s)<@class.method.attributeOperation.isMethod>.*?</@class.method.attributeOperation.isMethod>", method.getAttributeOperation() instanceof org.soluc.gen.project.Method ? getTagContent(code, "@class.method.attributeOperation.isMethod") : "");
        }
        while (code.contains("<@class.method.isSumOperation>")) {
            code = code.replaceFirst("\\ *(?s)<@class.method.isSumOperation>.*?</@class.method.isSumOperation>", method.getOperation() == org.soluc.gen.project.method.ListAttOperation.Operation.SUM ? getTagContent(code, "@class.method.isSumOperation") : "");
        }
        while (code.contains("<@class.method.isAvgOperation>")) {
            code = code.replaceFirst("\\ *(?s)<@class.method.isAvgOperation>.*?</@class.method.isAvgOperation>", method.getOperation() == org.soluc.gen.project.method.ListAttOperation.Operation.AVG ? getTagContent(code, "@class.method.isAvgOperation") : "");
        }
        while (code.contains("<@class.method.isMaxOperation>")) {
            code = code.replaceFirst("\\ *(?s)<@class.method.isMaxOperation>.*?</@class.method.isMaxOperation>", method.getOperation() == org.soluc.gen.project.method.ListAttOperation.Operation.MAX ? getTagContent(code, "@class.method.isMaxOperation") : "");
        }
        while (code.contains("<@class.method.isMinOperation>")) {
            code = code.replaceFirst("\\ *(?s)<@class.method.isMinOperation>.*?</@class.method.isMinOperation>", method.getOperation() == org.soluc.gen.project.method.ListAttOperation.Operation.MIN ? getTagContent(code, "@class.method.isMinOperation") : "");
        }
        return code;
    }

}
