package org.soluc.gen.project;

/**
 * @since 2017-06-11
 * @author marcos morise
 */
public abstract class Property {

    private String name = "";

    /**
     * Construtor
     */
    public Property() {
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the name with the first char uppercase
     */
    public String getNameU() {
        return (name.isEmpty() ? "" : name.substring(0, 1).toUpperCase() + name.substring(1, name.length()));
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        if (name.length() > 0) {
            //Remove acentos
            name = java.util.regex.Pattern.compile("\\p{InCombiningDiacriticalMarks}+").matcher(java.text.Normalizer.normalize(name.trim(), java.text.Normalizer.Form.NFD)).replaceAll("");
            name = name.replaceAll("[^A-Za-z0-9_]+", "");
            //Define a primeira letra minuscula
            this.name = name.substring(0, 1).toLowerCase() + name.substring(1, name.length());
        } else {
            this.name = "";
        }
    }

    /**
     * @return clone
     */
    public Property cloneThis() {
        return null;
    }
}
