package org.soluc.gen.project.method;

/**
 *
 * @author marcos morise
 * @since 2016-11-18
 */
public class AttOperation extends org.soluc.gen.project.Method {

    private java.util.List expression = new java.util.ArrayList<>();

    /**
     * Construtor
     */
    public AttOperation() {

    }

    /**
     * @return the type
     */
    @Override
    public Type getType() {
        return Type.METHOD_ATT_OPERATION;
    }

    /**
     * @return the expression
     */
    public java.util.List getExpression() {
        return expression;
    }

    /**
     * @param expression the expression to set
     */
    public void setExpression(java.util.List expression) {
        this.expression = expression;
    }

    /**
     * @param elem element of expression
     * @return if element is numeric
     */
    public java.lang.Boolean isElementNumeric(Object elem) {
        Boolean is = true;
        if (elem instanceof String) {
            try {
                Float.parseFloat(elem.toString());
            } catch (NumberFormatException ex) {
                is = false;
            }
        } else {
            is = false;
        }
        return is;
    }

    /**
     * @param elem element of Property
     * @return if element is Property
     */
    public java.lang.Boolean isElementProperty(Object elem) {
        Boolean is = true;
        if (elem instanceof String) {
            is = false;
        }
        return is;
    }

    /**
     * @param elem element of operator
     * @return if element is operator
     */
    public java.lang.Boolean isElementOperator(Object elem) {
        Boolean is = true;
        if (elem instanceof String) {
            if (elem.toString().compareTo("+") != 0 && elem.toString().compareTo("-") != 0
                    && elem.toString().compareTo("*") != 0 && elem.toString().compareTo("/") != 0 && elem.toString().compareTo("%") != 0) {
                is = false;
            }
        } else {
            is = false;
        }
        return is;
    }

    /**
     * @param elem element of Open Parentheses
     * @return if element is Open Parentheses
     */
    public java.lang.Boolean isElementOpenParentheses(Object elem) {
        Boolean is = true;
        if (elem instanceof String) {
            if (elem.toString().compareTo("(") != 0) {
                is = false;
            }
        } else {
            is = false;
        }
        return is;
    }

    /**
     * @param elem element of Close Parentheses
     * @return if element is Close Parentheses
     */
    public java.lang.Boolean isElementCloseParentheses(Object elem) {
        Boolean is = true;
        if (elem instanceof String) {
            if (elem.toString().compareTo(")") != 0) {
                is = false;
            }
        } else {
            is = false;
        }
        return is;
    }

    /**
     * @param e element to add in expression
     * @return if can add to expression
     */
    public java.lang.Boolean canAdd(String e) {
        Boolean can = true;
        if (isElementNumeric(e)) { // is Numeric
            if (!expression.isEmpty()) {
                Object o = expression.get(expression.size() - 1);
                if (isElementProperty(o) || isElementNumeric(o) || isElementCloseParentheses(o)) {
                    can = false;
                }
            }
        } else { //not Numeric
            can = true;
            if (!expression.isEmpty()) {
                Object o = expression.get(expression.size() - 1);
                if (e.compareTo(")") == 0) {
                    //Verify if open parentheses matches close parentheses 
                    int nParenthesesOpen = 0;
                    int nParenthesesClose = 0;
                    for (int i = 0; i < getExpression().size(); i++) {
                        Object el = expression.get(i);
                        if (isElementOpenParentheses(el)) {
                            nParenthesesOpen++;
                        }
                        if (isElementCloseParentheses(el)) {
                            nParenthesesClose++;
                        }
                    }
                    if (nParenthesesOpen <= nParenthesesClose) { //don't matches
                        can = false;
                    } else {
                        if (isElementOpenParentheses(o) || isElementOperator(o)) {
                            can = false;
                        }
                    }
                } else if (e.compareTo("(") == 0) {
                    if (isElementProperty(o) || isElementNumeric(o) || isElementCloseParentheses(o)) {
                        can = false;
                    }
                } else { //Operator
                    if (isElementOperator(o) || isElementOpenParentheses(o)) {
                        can = false;
                    }
                }
            } else {
                if (e.compareTo("(") != 0) {
                    can = false;
                }
            }
        }
        return can;
    }

    /**
     * @param e element to add in expression
     * @return if can add to expression
     */
    public java.lang.Boolean canAdd(org.soluc.gen.project.Property e) {
        Boolean can = true;
        if (!expression.isEmpty()) {
            Object o = expression.get(expression.size() - 1);
            if (isElementProperty(o) || isElementNumeric(o) || isElementCloseParentheses(o)) {
                can = false;
            }
        }
        return can;
    }

    /**
     * @return clone
     */
    @Override
    public AttOperation cloneThis() {
        AttOperation clone = new AttOperation();
        clone.setName(this.getName());
        return clone;
    }

    /**
     * @return expression code
     */
    public String getExpressionCode() {
        String code = "";
        for (int i = 0; i < getExpression().size(); i++) {
            if (isElementProperty(getExpression().get(i))) {
                org.soluc.gen.project.Property m = (org.soluc.gen.project.Property) getExpression().get(i);
                if (m instanceof org.soluc.gen.project.Method) {
                    code += m.getName() + "()";
                } else {
                    code += m.getName();
                }
            } else {
                code += getExpression().get(i).toString();
            }
            code += " ";
        }
        int nParenthesesOpen = 0;
        int nParenthesesClose = 0;
        for (int i = 0; i < getExpression().size(); i++) {
            Object el = getExpression().get(i);
            if (isElementOpenParentheses(el)) {
                nParenthesesOpen++;
            }
            if (isElementCloseParentheses(el)) {
                nParenthesesClose++;
            }
        }
        for (int i = nParenthesesClose; i < nParenthesesOpen; i++) {
            code += ")";
        }
        return code;
    }
}
