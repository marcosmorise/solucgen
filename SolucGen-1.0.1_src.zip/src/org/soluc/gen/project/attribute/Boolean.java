package org.soluc.gen.project.attribute;

/**
 * 
 * @author marcos
 */
public final class Boolean extends org.soluc.gen.project.Attribute {
    private java.lang.Boolean indexed = false;
    private java.lang.Boolean startValue = false;
    
    /**
     * Constructor
     */
    public Boolean() {
    }

    /**
     * @return the type
     */
    @Override
    public Type getType() {
        return Type.BOOLEAN;
    }

    /**
     * @return the Indexed
     */
    @Override
    public java.lang.Boolean isIndexed() {
        return indexed;
    }
    
    /**
     * @return the Indexed
     */
    public java.lang.Boolean getIndexed() {
        return indexed;
    }

    /**
     * @param indexed true is indexed | false isn't indexed
     */
    public void setIndexed(java.lang.Boolean indexed) {
        this.indexed = indexed;
    }

    /**
     * @return the startValue
     */
    public java.lang.Boolean getStartValue() {
        return startValue;
    }

    /**
     * @param startValue the startValue to set
     */
    public void setStartValue(java.lang.Boolean startValue) {
        this.startValue = startValue;
    }

    /**
     * @return clone
     */
    @Override
    public Boolean cloneThis() {
        Boolean clone = new Boolean();
        
        clone.setName(this.getName());
        clone.indexed = this.indexed;
        clone.startValue = this.startValue;
        return clone;
    }

}
