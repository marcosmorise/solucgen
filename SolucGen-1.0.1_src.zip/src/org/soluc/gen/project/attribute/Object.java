package org.soluc.gen.project.attribute;

/**
 * 
 * @author marcos morise
 */
public final class Object extends org.soluc.gen.project.Attribute {
    
    private org.soluc.gen.project.ClassBean classRef = null;
    private org.soluc.gen.project.Attribute attribLookUp = null;

    /**
     * @return the type
     */
    @Override
    public Type getType() {
        return Type.OBJECT;
    }

    /**
     * @return the classRef
     */
    public org.soluc.gen.project.ClassBean getClassRef() {
        return classRef;
    }

    /**
     * @param classRef the classRef to set
     */
    public void setClassRef(org.soluc.gen.project.ClassBean classRef) {
        this.classRef = classRef;
    }

    /**
     * @return the attribLookUp
     */
    public org.soluc.gen.project.Attribute getAttribLookUp() {
        return attribLookUp;
    }

    /**
     * @param attribLookUp the attribLookUp to set
     */
    public void setAttribLookUp(org.soluc.gen.project.Attribute attribLookUp) {
        this.attribLookUp = attribLookUp;
    }

    /**
     * @return clone
     */
    @Override
    public Object cloneThis() {
        Object clone = new Object();
        clone.setName(this.getName());
        clone.classRef = null;
        clone.attribLookUp = null;
        return clone;
    }
}
