package org.soluc.gen.project.attribute;

/**
 * @author marcos morise
 */
public final class Long extends org.soluc.gen.project.Attribute {

    private java.lang.Boolean unique = false;
    private java.lang.Boolean indexed = false;
    private java.lang.Long startValue = 0L;
    private java.lang.Boolean autoIncrement = false;
    private java.lang.Boolean abs = false;

    /**
     * Construtor
     */
    public Long() {
    }

    /**
     * @return the type
     */
    @Override
    public Type getType() {
        return Type.LONG;
    }

    /**
     * @return true if return method is Integer or Float || false otherwise
     */
    @Override
    public java.lang.Boolean isNumericReturn() {
        return true;
    }

    /**
     * @return if is Unique
     */
    @Override
    public java.lang.Boolean isUnique() {
        return unique;
    }

    /**
     * @return the unique
     */
    public java.lang.Boolean getUnique() {
        return unique;
    }

    /**
     * @param unique the unique to set
     */
    public void setUnique(java.lang.Boolean unique) {
        this.unique = unique;
        if (unique) {
            this.indexed = false;
        }
    }

    /**
     * @return if is Indexed
     */
    @Override
    public java.lang.Boolean isIndexed() {
        return indexed;
    }

    /**
     * @return the indexed
     */
    public java.lang.Boolean getIndexed() {
        return indexed;
    }

    /**
     * @param indexed the indexed to set
     */
    public void setIndexed(java.lang.Boolean indexed) {
        this.indexed = indexed;
        if (indexed) {
            this.unique = false;
        }
    }

    /**
     * @return the startValue
     */
    public java.lang.Long getStartValue() {
        return startValue;
    }

    /**
     * @param startValue the startValue to set
     */
    public void setStartValue(java.lang.Long startValue) {
        this.startValue = startValue;
    }

    /**
     * @param startValue the startValue to set
     */
    public void setStartValue(java.lang.String startValue) {
        try {
            this.startValue = java.lang.Long.parseLong(startValue);
        } catch (NumberFormatException e) {
            this.startValue = 0L;
        }
    }

    /**
     * @return the autoIncrement
     */
    public java.lang.Boolean isAutoIncrement() {
        return autoIncrement;
    }

    /**
     * @return the autoIncrement
     */
    public java.lang.Boolean getAutoIncrement() {
        return autoIncrement;
    }

    /**
     * @param autoIncrement the autoIncrement to set
     */
    public void setAutoIncrement(java.lang.Boolean autoIncrement) {
        this.autoIncrement = autoIncrement;
        if (autoIncrement) {
            this.unique = true;
            this.indexed = false;
        }
    }

    /**
     * @return the abs
     */
    public java.lang.Boolean isAbs() {
        return abs;
    }

    /**
     * @return the abs
     */
    public java.lang.Boolean getAbs() {
        return abs;
    }

    /**
     * @param abs the abs to set
     */
    public void setAbs(java.lang.Boolean abs) {
        this.abs = abs;
        if(abs) {
            this.autoIncrement = false;
        }
    }

    /**
     * @return clone
     */
    @Override
    public Long cloneThis() {
        Long clone = new Long();
        clone.setName(this.getName());
        clone.unique = this.unique;
        clone.indexed = this.indexed;
        clone.startValue = this.startValue;
        clone.autoIncrement = this.autoIncrement;
        clone.abs = this.abs;
        return clone;
    }

}
