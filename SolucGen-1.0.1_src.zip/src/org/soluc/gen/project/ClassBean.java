package org.soluc.gen.project;

/**
 * @author marcos morise
 * @since 2014-12-18
 */
public final class ClassBean {

    private Integer x = 0;
    private Integer y = 0;

    private String name = "";
    private java.util.List<Attribute> attributes = new java.util.ArrayList<>();
    private java.util.List<Method> methods = new java.util.ArrayList<>();

    /**
     * Constructor
     */
    public ClassBean() {

    }

    /**
     * @return the x
     */
    public Integer getX() {
        return x;
    }

    /**
     * @param x the x to set
     */
    public void setX(Integer x) {
        this.x = x;
    }

    /**
     * @return the y
     */
    public Integer getY() {
        return y;
    }

    /**
     * @param y the y to set
     */
    public void setY(Integer y) {
        this.y = y;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the name with the first char lowercase
     */
    public String getNameL() {
        return (name.isEmpty() ? "" : name.substring(0, 1).toLowerCase() + name.substring(1, name.length()));
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        if (name.length() > 0) {
            //Remove acentos
            name = java.util.regex.Pattern.compile("\\p{InCombiningDiacriticalMarks}+").matcher(java.text.Normalizer.normalize(name.trim(), java.text.Normalizer.Form.NFD)).replaceAll("");
            name = name.replaceAll("[^A-Za-z0-9_]+", "");
            this.name = name.substring(0, 1).toUpperCase() + name.substring(1, name.length());
        } else {
            this.name = "";
        }
    }

    /**
     * @return the attributes
     */
    public java.util.List<Attribute> getAttributes() {
        return attributes;
    }

    /**
     * @param attributes the attributes to set
     */
    public void setAttributes(java.util.List<Attribute> attributes) {
        this.attributes = attributes;
    }

    /**
     * @return the methods
     */
    public java.util.List<Method> getMethods() {
        return methods;
    }

    /**
     * @param methods the methods to set
     */
    public void setMethods(java.util.List<Method> methods) {
        this.methods = methods;
    }

    /**
     * @param property the property to move
     */
    public void moveTop(Property property) {
        if (property instanceof Attribute) {
            int idx = getAttributes().indexOf(property);
            if (idx > 0) {
                getAttributes().remove(idx);
                getAttributes().add(0, (Attribute) property);
            }
        } else {
            int idx = getMethods().indexOf(property);
            if (idx > 0) {
                getMethods().remove(idx);
                getMethods().add(0, (Method) property);
            }
        }
    }

    /**
     * @param property the property to move
     */
    public void moveBottom(Property property) {
        if (property instanceof Attribute) {
            int idx = getAttributes().indexOf(property);
            if (idx > 0) {
                getAttributes().remove(idx);
                getAttributes().add((Attribute) property);
            }
        } else {
            int idx = getMethods().indexOf(property);
            if (idx > 0) {
                getMethods().remove(idx);
                getMethods().add((Method) property);
            }
        }
    }

    /**
     * @param property the property to move
     */
    public void moveUp(Property property) {
        if (property instanceof Attribute) {
            int idx = getAttributes().indexOf(property);
            if (idx > 0) {
                getAttributes().remove(idx);
                getAttributes().add(idx - 1, (Attribute) property);
            }
        } else {
            int idx = getMethods().indexOf(property);
            if (idx > 0) {
                getMethods().remove(idx);
                getMethods().add(idx - 1, (Method) property);
            }
        }
    }

    /**
     * @param property the property to move
     */
    public void moveDown(Property property) {
        if (property instanceof Attribute) {
            int idx = getAttributes().indexOf(property);
            if (idx > 0) {
                getAttributes().remove(idx);
                getAttributes().add(idx + 1, (Attribute) property);
            }
        } else {
            int idx = getMethods().indexOf(property);
            if (idx > 0) {
                getMethods().remove(idx);
                getMethods().add(idx + 1, (Method) property);
            }
        }
    }

    /**
     * @param type
     * @return the Properties by Type
     */
    public java.util.List<Attribute> getAttributes(Attribute.Type type) {
        java.util.List<Attribute> attributesTyped = new java.util.ArrayList();
        for (Attribute a : getAttributes()) {
            if (a.getType() == type) {
                attributesTyped.add(a);
            }
        }
        return attributesTyped;
    }

    /**
     * @return the uniqueAttributes
     */
    public java.util.List<Attribute> getUniqueAttributes() {
        java.util.List<Attribute> uniqueAttributes = new java.util.ArrayList();
        for (Attribute a : getAttributes()) {
            if (a.isUnique()) {
                uniqueAttributes.add(a);
            }
        }
        return uniqueAttributes;
    }

    /**
     * @return the indexedAttributes
     */
    public java.util.List<Attribute> getIndexedAttributes() {
        java.util.List<Attribute> indexedAttributes = new java.util.ArrayList();
        for (Attribute a : getAttributes()) {
            if (a.isIndexed()) {
                indexedAttributes.add(a);
            }
        }
        return indexedAttributes;
    }

    /**
     * @return the numeric return Attributes
     */
    public java.util.List<Attribute> getNumericAttributes() {
        java.util.List<Attribute> numericAttributes = new java.util.ArrayList();
        for (Attribute a : getAttributes()) {
            if (a.isNumericReturn()) {
                numericAttributes.add(a);
            }
        }
        return numericAttributes;
    }

    /**
     * @return the numeric return Methods
     */
    public java.util.List<Method> getNumericMethods() {
        java.util.List<Method> numericMethods = new java.util.ArrayList();
        for (Method m : getMethods()) {
            if ((m instanceof org.soluc.gen.project.method.AttOperation) || (m instanceof org.soluc.gen.project.method.ListAttOperation)) {
                numericMethods.add(m);
            }
        }
        return numericMethods;
    }

    /**
     * @param name
     * @return the property by name
     */
    public Property getProperty(String name) {
        Property property = null;
        if (name != null && name.length() > 0) {
            //Remove acentos
            name = java.util.regex.Pattern.compile("\\p{InCombiningDiacriticalMarks}+").matcher(java.text.Normalizer.normalize(name.trim(), java.text.Normalizer.Form.NFD)).replaceAll("");
            name = name.replaceAll("[^A-Za-z0-9_]+", "");
            //Define a primeira letra minuscula
            name = name.substring(0, 1).toLowerCase() + name.substring(1, name.length());
            //Busca em atributos
            for (Property p : getAttributes()) {
                if (p.getName().compareTo(name) == 0) {
                    property = p;
                }
            }
            //Busca em metodos
            if (property == null) {
                for (Property p : getMethods()) {
                    if (p.getName().compareTo(name) == 0) {
                        property = p;
                    }
                }
            }
        }
        return property;
    }

    /**
     * @param name
     * @return if has the property by name
     */
    public Boolean hasProperty(String name) {
        Boolean has = false;
        Property property = getProperty(name);
        if (property != null) {
            has = true;
        }
        return has;
    }

    /**
     * @return if has Unique Property
     */
    public Boolean hasUniqueAttribute() {
        Boolean has = false;
        for (Attribute a : getAttributes()) {
            if (a.isUnique()) {
                has = true;
            }
        }
        return has;
    }

    /**
     * @return the first unique attribute
     */
    public Attribute getFirstUniqueAttribute() {
        Attribute att = null;
        Integer i = 0;
        while (att == null && i < getAttributes().size()) {
            Attribute p = getAttributes().get(i);
            if (p.isUnique()) {
                att = p;
            }
            i++;
        }
        return att;
    }

    /**
     * @return clone
     */
    public ClassBean cloneThis() {
        ClassBean clone = new ClassBean();
        clone.name = this.name;
        for (Attribute p : getAttributes()) {
            if (p.getType() != org.soluc.gen.project.Attribute.Type.LIST) {
                clone.getAttributes().add(p.cloneThis());
            }
        }
        for (Method p : getMethods()) {
            if (p.getType() != org.soluc.gen.project.Method.Type.METHOD_CUSTOM_CODE && p.getType() != org.soluc.gen.project.Method.Type.METHOD_LIST_ATT_OPERATION) {
                clone.getMethods().add(p.cloneThis());
            }
        }
        return clone;
    }

}
