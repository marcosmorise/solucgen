package org.soluc.gen.project;

/**
 * @author marcos morise
 * @since 2014-12-18
 */
public abstract class Attribute extends Property {

    public static enum Type {
        BOOLEAN("Boolean"),
        BYTE("Byte"),
        SHORT("Short"),
        INTEGER("Integer"),
        LONG("Long"),
        FLOAT("Float"),
        DOUBLE("Double"),
        CHARACTER("Character"),
        STRING("String"),
        DATE("Date"),
        TIME("Time"),
        ENUM("Emun"),
        IMAGE("Image"),
        OBJECT("Object"),
        LIST("List");

        public String label;

        Type(String label) {
            this.label = label;
        }

        /**
         * @return Type labels
         */
        public static String[] getLabels() {
            String[] labels = new String[values().length];
            for (int i = 0; i < Type.values().length; i++) {
                labels[i] = Type.values()[i].label;
            }
            return labels;
        }
    }

    /**
     * Construtor
     */
    public Attribute() {
    }

    /**
     * @return the type
     */
    public Type getType() {
        return null;
    }

    /**
     * @return if is UNIQUE
     */
    public Boolean isUnique() {
        return false;
    }

    /**
     * @return if is INDEXED
     */
    public Boolean isIndexed() {
        return false;
    }

    /**
     * @return true if return method is Integer or Float || false otherwise
     */
    public Boolean isNumericReturn() {
        return false;
    }

    /**
     * @return clone
     */
    @Override
    public Attribute cloneThis() {
        return null;
    }
}
