package org.soluc.gen.project;

/**
 * @author marcos morise
 * @since 2014-12-18
 */
public abstract class Method extends Property {

    public static enum Type {
        METHOD_BLANK("Blank Method"),
        METHOD_CUSTOM_CODE("Custom Code Method"),
        METHOD_ATT_OPERATION("Attribute Operation"),
        METHOD_LIST_ATT_OPERATION("List Attribute Operation");

        public String label;

        Type(String label) {
            this.label = label;
        }

        /**
         * @return Type labels
         */
        public static String[] getLabels() {
            String[] labels = new String[values().length];
            for (int i = 0; i < Type.values().length; i++) {
                labels[i] = Type.values()[i].label;
            }
            return labels;
        }

    }

    /**
     * Construtor
     */
    public Method() {
    }

    /**
     * @return the type
     */
    public Type getType() {
        return null;
    }

    /**
     * @return clone
     */
    @Override
    public Method cloneThis() {
        return null;
    }
}
