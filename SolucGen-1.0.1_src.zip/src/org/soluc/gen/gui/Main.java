package org.soluc.gen.gui;

import org.soluc.gen.project.Project;

/**
 * @since 2017-06-11
 * @author marcos morise
 */
public final class Main extends javax.swing.JFrame {

    public static final String VERSION = "1.0.1";

    public static final String[] RESERVED_KEYWORDS = {
        "abstract", "continue", "for", "new", "switch", "assert", "default", "goto", "package", "synchronized", "boolean", "do", "if", "private", "this", "break", "double", "implements", "protected", "throw", "byte", "else", "import", "public", "throws", "case", "enum", "instanceof", "return", "transient", "catch", "extends", "int", "short", "try", "char", "final", "interface", "static", "void", "class", "finally", "long", "strictfp", "volatile", "const", "float", "native", "super", "while"
    };

    /**
     * isReservedWord
     *
     * @param word
     * @return true is Reserved Word || false not is Reserved Word
     */
    public static final boolean isReservedWord(String word) {
        boolean is = false;
        word = java.util.regex.Pattern.compile("\\p{InCombiningDiacriticalMarks}+").matcher(java.text.Normalizer.normalize(word.trim(), java.text.Normalizer.Form.NFD)).replaceAll("");
        word = word.replaceAll("[^A-Za-z0-9_]+", "").toLowerCase();
        for (String s : RESERVED_KEYWORDS) {
            if (s.compareTo(word) == 0) {
                is = true;
            }
        }
        return is;
    }

    private final java.util.List<DiagramPanel> diagrams;
    private org.soluc.gen.project.ClassBean clipboardClass;

    /**
     * Creates new form Main
     */
    private Main() {
        super();
        this.diagrams = new java.util.ArrayList<>();
        this.clipboardClass = null;
        initComponents();

        //Only for development
        bCodeTemplateEditor.setVisible(false);
        bGenerate.setVisible(false);
        //Only for development

        tabs.setComponentPopupMenu(popupMenu);
        refreshButtonsState();
        this.setIconImage(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/SolucGen.png")).getImage());
        this.setTitle("SolucGen " + VERSION);
        this.setVisible(true);
        StartForm.showDialog(this);
    }

    /**
     * Show main dialog
     */
    public static void showDialog() {
        new Main();
    }

    /**
     * @return the clipboardClass
     */
    public org.soluc.gen.project.ClassBean getClipboardClass() {
        return clipboardClass;
    }

    /**
     * @param clipboardClass the clipboardClass to set
     */
    public void setClipboardClass(org.soluc.gen.project.ClassBean clipboardClass) {
        this.clipboardClass = clipboardClass;
    }

    /**
     * Refresh buttons state
     */
    public void refreshButtonsState() {
        if (diagrams.size() > 0) {
            bSave.setEnabled(true);
            bSaveAs.setEnabled(true);
            bGenerate.setEnabled(true);
            bProjectGenerate.setEnabled(true);
            mSave.setEnabled(true);
            mRename.setEnabled(true);
            mClose.setEnabled(true);
        } else {
            bSave.setEnabled(false);
            bSaveAs.setEnabled(false);
            bGenerate.setEnabled(false);
            bProjectGenerate.setEnabled(false);
            mSave.setEnabled(false);
            mRename.setEnabled(false);
            mClose.setEnabled(false);
        }
        if (tabs.getSelectedIndex() >= 0) {
            DiagramPanel diagram = diagrams.get(tabs.getSelectedIndex());
            bSave.setEnabled(diagram.isEdited());
        }        
    }

    /**
     * @return File filter
     */
    private javax.swing.filechooser.FileFilter getFileFilter() {
        return new javax.swing.filechooser.FileFilter() {
            @Override
            public String getDescription() {
                return "SolucGen files (*.slgen)";
            }

            @Override
            public boolean accept(java.io.File file) {
                return file.getName().endsWith(".slgen") || file.isDirectory();
            }
        };
    }

    /**
     * Method for StartForm
     *
     * @param evt
     */
    public void newActionPerformed(java.awt.event.ActionEvent evt) {
        bNewActionPerformed(evt);
    }

    /**
     * Method for StartForm
     *
     * @param evt
     */
    public void openActionPerformed(java.awt.event.ActionEvent evt) {
        bOpenActionPerformed(evt);
    }

    /**
     * Method for StartForm
     *
     * @param evt
     */
    public void closeActionPerformed(java.awt.event.ActionEvent evt) {
        mCloseActionPerformed(evt);
    }

    /**
     * Close Current project
     */
    public void closeCurrentProject() {
        if (tabs.getSelectedIndex() >= 0) {
            DiagramPanel diagram = diagrams.get(tabs.getSelectedIndex());
            Project project = diagram.getProject();
            if (project != null) {
                if (diagram.isEdited()) {
                    int resp = javax.swing.JOptionPane.showConfirmDialog(this, "Project " + project.getName() + " was modified!\nWould you like save project before close?", "Save project", javax.swing.JOptionPane.YES_NO_CANCEL_OPTION);
                    switch (resp) {
                        case javax.swing.JOptionPane.CANCEL_OPTION:
                            return;
                        case javax.swing.JOptionPane.YES_OPTION:
                            mSaveActionPerformed(null);
                            break;
                        case javax.swing.JOptionPane.NO_OPTION:
                            break;
                    }
                }
                tabs.remove(diagram);
                diagrams.remove(diagram);
                refreshButtonsState();
            }
        }
    }

    /**
     * Method for StartForm
     *
     * @return
     */
    public Integer getNTabs() {
        return tabs.getTabCount();
    }

//******************************************************************************
//******************************************************************************
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        popupMenu = new javax.swing.JPopupMenu();
        mNew = new javax.swing.JMenuItem();
        mOpen = new javax.swing.JMenuItem();
        mSave = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        mRename = new javax.swing.JMenuItem();
        mClose = new javax.swing.JMenuItem();
        toolBar = new javax.swing.JToolBar();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        bNew = new javax.swing.JButton();
        bOpen = new javax.swing.JButton();
        bSave = new javax.swing.JButton();
        bSaveAs = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JToolBar.Separator();
        bProjectGenerate = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        bGenerate = new javax.swing.JButton();
        bCodeTemplateEditor = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JToolBar.Separator();
        bCredits = new javax.swing.JButton();
        bAbout = new javax.swing.JButton();
        bHelp = new javax.swing.JButton();
        tabs = new javax.swing.JTabbedPane();

        mNew.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/page_white.png"))); // NOI18N
        mNew.setText("New project");
        mNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mNewActionPerformed(evt);
            }
        });
        popupMenu.add(mNew);

        mOpen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/folder_page_white.png"))); // NOI18N
        mOpen.setText("Open project");
        mOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mOpenActionPerformed(evt);
            }
        });
        popupMenu.add(mOpen);

        mSave.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/disk.png"))); // NOI18N
        mSave.setText("Save project");
        mSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mSaveActionPerformed(evt);
            }
        });
        popupMenu.add(mSave);
        popupMenu.add(jSeparator1);

        mRename.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/textfield_edit.png"))); // NOI18N
        mRename.setText("Rename project");
        mRename.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mRenameActionPerformed(evt);
            }
        });
        popupMenu.add(mRename);

        mClose.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/cross.png"))); // NOI18N
        mClose.setText("Close project");
        mClose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mCloseActionPerformed(evt);
            }
        });
        popupMenu.add(mClose);

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        toolBar.setRollover(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        bNew.setBackground(new java.awt.Color(255, 255, 255));
        bNew.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/page_white.png"))); // NOI18N
        bNew.setMnemonic('N');
        bNew.setToolTipText("New project (Alt+N)");
        bNew.setFocusable(false);
        bNew.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bNew.setPreferredSize(new java.awt.Dimension(28, 28));
        bNew.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bNewActionPerformed(evt);
            }
        });
        jPanel2.add(bNew);

        bOpen.setBackground(new java.awt.Color(255, 255, 255));
        bOpen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/folder_page_white.png"))); // NOI18N
        bOpen.setMnemonic('O');
        bOpen.setToolTipText("Open project (Alt+O)");
        bOpen.setFocusable(false);
        bOpen.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bOpen.setPreferredSize(new java.awt.Dimension(28, 28));
        bOpen.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bOpenActionPerformed(evt);
            }
        });
        jPanel2.add(bOpen);

        bSave.setBackground(new java.awt.Color(255, 255, 255));
        bSave.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/disk.png"))); // NOI18N
        bSave.setMnemonic('S');
        bSave.setToolTipText("Save project (Alt+S)");
        bSave.setFocusable(false);
        bSave.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bSave.setPreferredSize(new java.awt.Dimension(28, 28));
        bSave.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSaveActionPerformed(evt);
            }
        });
        jPanel2.add(bSave);

        bSaveAs.setBackground(new java.awt.Color(255, 255, 255));
        bSaveAs.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/disk_as.png"))); // NOI18N
        bSaveAs.setToolTipText("Save project as");
        bSaveAs.setFocusable(false);
        bSaveAs.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bSaveAs.setPreferredSize(new java.awt.Dimension(28, 28));
        bSaveAs.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bSaveAs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSaveAsActionPerformed(evt);
            }
        });
        jPanel2.add(bSaveAs);
        jPanel2.add(jSeparator2);

        bProjectGenerate.setBackground(new java.awt.Color(255, 255, 255));
        bProjectGenerate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/application.png"))); // NOI18N
        bProjectGenerate.setToolTipText("Generate project");
        bProjectGenerate.setFocusable(false);
        bProjectGenerate.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bProjectGenerate.setPreferredSize(new java.awt.Dimension(28, 28));
        bProjectGenerate.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bProjectGenerate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bProjectGenerateActionPerformed(evt);
            }
        });
        jPanel2.add(bProjectGenerate);

        jPanel1.add(jPanel2, java.awt.BorderLayout.WEST);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        bGenerate.setBackground(new java.awt.Color(255, 255, 255));
        bGenerate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/script.png"))); // NOI18N
        bGenerate.setToolTipText("Generate code");
        bGenerate.setFocusable(false);
        bGenerate.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bGenerate.setPreferredSize(new java.awt.Dimension(28, 28));
        bGenerate.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bGenerate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bGenerateActionPerformed(evt);
            }
        });
        jPanel3.add(bGenerate);

        bCodeTemplateEditor.setBackground(new java.awt.Color(255, 255, 255));
        bCodeTemplateEditor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/book.png"))); // NOI18N
        bCodeTemplateEditor.setToolTipText("Code Template Editor");
        bCodeTemplateEditor.setFocusable(false);
        bCodeTemplateEditor.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bCodeTemplateEditor.setPreferredSize(new java.awt.Dimension(28, 28));
        bCodeTemplateEditor.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bCodeTemplateEditor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCodeTemplateEditorActionPerformed(evt);
            }
        });
        jPanel3.add(bCodeTemplateEditor);
        jPanel3.add(jSeparator3);

        bCredits.setBackground(new java.awt.Color(255, 255, 255));
        bCredits.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/brick.png"))); // NOI18N
        bCredits.setToolTipText("Credits");
        bCredits.setFocusable(false);
        bCredits.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bCredits.setPreferredSize(new java.awt.Dimension(28, 28));
        bCredits.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bCredits.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCreditsActionPerformed(evt);
            }
        });
        jPanel3.add(bCredits);

        bAbout.setBackground(new java.awt.Color(255, 255, 255));
        bAbout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/information.png"))); // NOI18N
        bAbout.setToolTipText("About");
        bAbout.setFocusable(false);
        bAbout.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bAbout.setPreferredSize(new java.awt.Dimension(28, 28));
        bAbout.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bAbout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAboutActionPerformed(evt);
            }
        });
        jPanel3.add(bAbout);

        bHelp.setBackground(new java.awt.Color(255, 255, 255));
        bHelp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/soluc/toolbox/images/help.png"))); // NOI18N
        bHelp.setToolTipText("Help");
        bHelp.setFocusable(false);
        bHelp.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bHelp.setPreferredSize(new java.awt.Dimension(28, 28));
        bHelp.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bHelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bHelpActionPerformed(evt);
            }
        });
        jPanel3.add(bHelp);

        jPanel1.add(jPanel3, java.awt.BorderLayout.EAST);

        toolBar.add(jPanel1);

        getContentPane().add(toolBar, java.awt.BorderLayout.PAGE_START);

        tabs.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        tabs.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                tabsStateChanged(evt);
            }
        });
        getContentPane().add(tabs, java.awt.BorderLayout.CENTER);

        setSize(new java.awt.Dimension(800, 600));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void bNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bNewActionPerformed
        String name = javax.swing.JOptionPane.showInputDialog(this, "Project name:", "new Project", javax.swing.JOptionPane.OK_CANCEL_OPTION);
        if (name != null && !name.isEmpty() && !isReservedWord(name)) {
            DiagramPanel diagram = new DiagramPanel(this);
            diagram.setProject(new org.soluc.gen.project.Project());
            diagram.getProject().setName(name);
            diagrams.add(diagram);
            tabs.add(name, diagram);
            tabs.setSelectedComponent(diagram);
            refreshButtonsState();
        }
    }//GEN-LAST:event_bNewActionPerformed

    private void bOpenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bOpenActionPerformed
        //Inicia o navegador de arquivos
        javax.swing.JFileChooser browser = new javax.swing.JFileChooser();
        browser.setFileSelectionMode(javax.swing.JFileChooser.FILES_ONLY);
        browser.setMultiSelectionEnabled(false);
        //browser.setCurrentDirectory(new java.io.File(currentDirectory));
        browser.setFileFilter(getFileFilter());

        //Exibe o navegador de arquivos, se o "Cancelar" for clicado retorna
        if (browser.showOpenDialog(this) == javax.swing.JFileChooser.CANCEL_OPTION) {
            return;
        }

        //Abre o arquivo
        String pathFile = browser.getSelectedFile().getAbsolutePath();
        try {
            Project project = new Project();
            project.loadXML(pathFile);
            DiagramPanel diagram = new DiagramPanel(this);
            diagram.setProject(project);
            diagram.setPathFile(pathFile);
            diagrams.add(diagram);
            tabs.add(project.getName(), diagram);
            tabs.setSelectedComponent(diagram);
            refreshButtonsState();
        } catch (java.io.FileNotFoundException e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Invalid file !");
        }
    }//GEN-LAST:event_bOpenActionPerformed

    private void bSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSaveActionPerformed
        DiagramPanel diagram = diagrams.get(tabs.getSelectedIndex());
        Project project = diagrams.get(tabs.getSelectedIndex()).getProject();
        String pathFile = diagram.getPathFile();
        if (pathFile.isEmpty()) {
            bSaveAsActionPerformed(evt);
        } else {
            try {
                project.saveXML(pathFile);
                diagram.setEdited(false);
                repaint();
            } catch (java.io.FileNotFoundException e) {
                javax.swing.JOptionPane.showMessageDialog(this, "Invalid file !");
            }
        }
    }//GEN-LAST:event_bSaveActionPerformed

    private void bSaveAsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSaveAsActionPerformed
        DiagramPanel diagram = diagrams.get(tabs.getSelectedIndex());
        Project project = diagrams.get(tabs.getSelectedIndex()).getProject();

        javax.swing.JFileChooser browser = new javax.swing.JFileChooser();
        browser.setFileSelectionMode(javax.swing.JFileChooser.FILES_ONLY);
        browser.setFileFilter(getFileFilter());
        browser.setMultiSelectionEnabled(false);
        browser.setCurrentDirectory(new java.io.File(diagram.getPathFile()));
        browser.setSelectedFile(new java.io.File(project.getName() + ".slgen"));

        //Exibe o navegador de arquivos, se o "Cancelar" for clicado retorna
        if (browser.showSaveDialog(this) == javax.swing.JFileChooser.CANCEL_OPTION) {
            return;
        }

        //Se o arquivo selecionado não terminar com ".slgen" adiciona o sufixo
        if (!browser.getSelectedFile().getName().endsWith(".slgen")) {
            browser.setSelectedFile(new java.io.File(browser.getSelectedFile().getAbsolutePath() + ".slgen"));
        }

        //Se o arquivo selecionado existir pede a confirmação de substituição
        if (browser.getSelectedFile().exists()) {
            String message = "File already exists!\nWould you like overwrite file?";
            if (javax.swing.JOptionPane.showConfirmDialog(this, message, "SolucGen", javax.swing.JOptionPane.OK_CANCEL_OPTION) == javax.swing.JOptionPane.CANCEL_OPTION) {
                return;
            }
        }

        //Salva o arquivo
        String pathFile = browser.getSelectedFile().getAbsolutePath();
        try {
            project.saveXML(pathFile);
            diagram.setEdited(false);
            diagram.setPathFile(pathFile);
            repaint();
        } catch (java.io.FileNotFoundException e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Invalid file !", "Error", javax.swing.JOptionPane.YES_NO_CANCEL_OPTION);
        }
    }//GEN-LAST:event_bSaveAsActionPerformed

    private void mNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mNewActionPerformed
        bNewActionPerformed(evt);
    }//GEN-LAST:event_mNewActionPerformed

    private void mOpenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mOpenActionPerformed
        bOpenActionPerformed(evt);
    }//GEN-LAST:event_mOpenActionPerformed

    private void mSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mSaveActionPerformed
        bSaveActionPerformed(evt);
    }//GEN-LAST:event_mSaveActionPerformed

    private void mRenameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mRenameActionPerformed
        if (tabs.getSelectedIndex() >= 0) {
            DiagramPanel diagram = diagrams.get(tabs.getSelectedIndex());
            Project project = diagrams.get(tabs.getSelectedIndex()).getProject();
            String name = javax.swing.JOptionPane.showInputDialog(this, "Project name:", project.getName());
            if (name != null && !name.isEmpty() && !isReservedWord(name)) {
                diagram.getProject().setName(name);
                diagram.setEdited(true);
                tabs.setTitleAt(tabs.getSelectedIndex(), name);
            }
        }
    }//GEN-LAST:event_mRenameActionPerformed

    private void mCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mCloseActionPerformed
        closeCurrentProject();
        if (getNTabs() == 0) {
            StartForm.showDialog(this);
        }
    }//GEN-LAST:event_mCloseActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        if (!diagrams.isEmpty()) {
            int size = diagrams.size();
            tabs.setSelectedIndex(0);
            closeCurrentProject();
            if (size > diagrams.size()) {
                formWindowClosing(evt);
            }
        } else {
            this.setVisible(false);
            this.dispose();
            System.exit(0);
        }
    }//GEN-LAST:event_formWindowClosing

    private void bGenerateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bGenerateActionPerformed
        if (!diagrams.isEmpty()) {
            DiagramPanel diagram = diagrams.get(tabs.getSelectedIndex());
            GeneratorForm.showDialog(this, diagram.getProject());
        }
    }//GEN-LAST:event_bGenerateActionPerformed

    private void bCodeTemplateEditorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCodeTemplateEditorActionPerformed
        CodeTemplateEditor.showDialog(this);
    }//GEN-LAST:event_bCodeTemplateEditorActionPerformed

    private void bProjectGenerateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bProjectGenerateActionPerformed
        if (!diagrams.isEmpty()) {
            DiagramPanel diagram = diagrams.get(tabs.getSelectedIndex());
            if (diagram.getProject().isValid() == 0) {
                ProjectGeneratorForm.showDialog(this, diagram.getProject());
            } else {
                javax.swing.JOptionPane.showMessageDialog(this, "The project has classes without a Primary Key!", "SolucGen " + VERSION, javax.swing.JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_bProjectGenerateActionPerformed

    private void bAboutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAboutActionPerformed
        String about = "";
        about += "SolucGen " + VERSION + "\n\n"
                + "Versão lançada em 20/09/2017\n"
                + "Versão atualizada em 29/09/2017\n"
                + "Mantido por SoLUC.org\n\n"
                + "site:\n"
                + "<http://soluc.org>\n\n"
                + "contato:\n"
                + "<org.soluc@gmail.com>\n"
                + "<marcosmorise@gmail.com>\n\n"
                + "© Copyright 2017 Marcos Juinthi Koba Morise\n\n"
                + "    SolucGen é um software livre; você pode redistribuí-lo e/ou modificá-lo\n"
                + "    dentro dos termos da Licença Pública Geral GNU como publicada \n"
                + "    pela Fundação do Software Livre (FSF); na versão 3 da Licença.\n\n"
                + "    SolucGen é distribuido na esperança que possa ser util,\n"
                + "    mas SEM NENHUMA GARANTIA; sem uma garantia implícita de \n"
                + "    ADEQUAÇÂO a qualquer MERCADO ou APLICAÇÃO EM PARTICULAR. \n\n"
                + "    Veja a Licença Pública Geral GNU para maiores detalhes.\n"
                + "    <http://www.gnu.org/licenses/>\n"
                + "\n";
        javax.swing.JOptionPane.showMessageDialog(this, about, "About SolucGen " + VERSION, javax.swing.JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_bAboutActionPerformed

    private void bHelpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bHelpActionPerformed
        java.awt.Desktop d = java.awt.Desktop.getDesktop();
        try {
            d.browse(new java.net.URI("http://soluc.org/solucgen"));
        } catch (java.io.IOException | java.net.URISyntaxException e) {
            javax.swing.JOptionPane.showMessageDialog(this, e.getMessage(), "Error SolucGen " + VERSION, javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bHelpActionPerformed

    private void bCreditsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCreditsActionPerformed
        String about = "";
        about += "SolucGen " + VERSION + "\n\n"
                + "Créditos:\n"
                + " Isabella Pegorete Mandetta de Souza\n"
                + " - Implementação da leitura do arquivo de metatags no editor de metacodigo\n\n"
                + " Jesaias Ismael da Costa\n"
                + " - Testes conceituais e operacionais. Reportagem de bugs.\n\n"
                + " Marcos Juinthi Koba Morise\n"
                + " - Desenvolvimento e abertura do código-fonte\n\n"
                + " Mario Shinzo Ganeko\n"
                + " - Testes conceituais e operacionais. Reportagem de bugs.\n\n"
                + " Paulo Silvio Amorim Augusto Ligeiro\n"
                + " - Criação do  arquivo de metatags\n\n"
                + "\n";
        javax.swing.JOptionPane.showMessageDialog(this, about, "About SolucGen " + VERSION, javax.swing.JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_bCreditsActionPerformed

    private void tabsStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_tabsStateChanged
        if (!diagrams.isEmpty() && tabs.getSelectedIndex() >= 0) {
            DiagramPanel diagram = diagrams.get(tabs.getSelectedIndex());
            bSave.setEnabled(diagram.isEdited());
        }
    }//GEN-LAST:event_tabsStateChanged

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAbout;
    private javax.swing.JButton bCodeTemplateEditor;
    private javax.swing.JButton bCredits;
    private javax.swing.JButton bGenerate;
    private javax.swing.JButton bHelp;
    private javax.swing.JButton bNew;
    private javax.swing.JButton bOpen;
    private javax.swing.JButton bProjectGenerate;
    private javax.swing.JButton bSave;
    private javax.swing.JButton bSaveAs;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JToolBar.Separator jSeparator2;
    private javax.swing.JToolBar.Separator jSeparator3;
    private javax.swing.JMenuItem mClose;
    private javax.swing.JMenuItem mNew;
    private javax.swing.JMenuItem mOpen;
    private javax.swing.JMenuItem mRename;
    private javax.swing.JMenuItem mSave;
    private javax.swing.JPopupMenu popupMenu;
    private javax.swing.JTabbedPane tabs;
    private javax.swing.JToolBar toolBar;
    // End of variables declaration//GEN-END:variables
}
