package org.soluc.gen.gui.method;

import org.soluc.gen.project.Attribute;
import org.soluc.gen.project.ClassBean;
import org.soluc.gen.project.Property;
import org.soluc.gen.project.Method;
import org.soluc.gen.project.Project;

/**
 *
 * @author marcos
 */
public final class AttOperationForm extends NoneForm {

    private org.soluc.gen.project.method.AttOperation m;
    
    /**
     * Creates new form ProjectForm
     *
     * @param project
     * @param classBean
     * @param method
     */
    public AttOperationForm(Project project, ClassBean classBean, Method method) {
        super(project, classBean, method);
        initComponents();
    }

    /**
     * Refresh data form
     */
    @Override
    public void obj2form() {
        if (this.method != null && this.method instanceof org.soluc.gen.project.method.AttOperation) {
            m = (org.soluc.gen.project.method.AttOperation) this.method;
        } else {
            m = new org.soluc.gen.project.method.AttOperation();
        }
        cAttributeMethodRefresh();
        refresh();
    }
    
    /**
     * 
     */
    @Override
    public void form2obj() {
       this.method = m; 
    }

    private void refresh() {
        String expressionBuilt = "<html>";
        expressionBuilt += "<p>";

        for (int i = 0; i < m.getExpression().size(); i++) {
            if (m.isElementProperty(m.getExpression().get(i))) {
                Property p = (Property) m.getExpression().get(i);
                if (p instanceof Method) {
                    expressionBuilt += "<b color=BLUE>";
                    expressionBuilt += p.getName() + "()";
                    expressionBuilt += "</b>";

                } else if (p instanceof Attribute) {
                    expressionBuilt += "<b color=GREEN>";
                    expressionBuilt += p.getName();
                    expressionBuilt += "</b>";
                }
            } else {
                expressionBuilt += m.getExpression().get(i).toString();
            }
            expressionBuilt += " ";
        }
        int nParenthesesOpen = 0;
        int nParenthesesClose = 0;
        for (int i = 0; i < m.getExpression().size(); i++) {
            Object el = m.getExpression().get(i);
            if (m.isElementOpenParentheses(el)) {
                nParenthesesOpen++;
            }
            if (m.isElementCloseParentheses(el)) {
                nParenthesesClose++;
            }
        }
        for (int i = nParenthesesClose; i < nParenthesesOpen; i++) {
            expressionBuilt += "<i color=RED>";
            expressionBuilt += ")";
            expressionBuilt += "</i>";
        }

        expressionBuilt += "</p>";
        expressionBuilt += "</html>";

        lExpression.setText(expressionBuilt);
        updateButtonsState();
    }

    /**
     * cAttributeList Refresh
     */
    private void cAttributeMethodRefresh() {
        java.util.List<Attribute> numericAtts = classBean.getNumericAttributes();
        java.util.List<Method> numericMets = classBean.getNumericMethods();
        cAttributeMethod.removeAllItems();
        for (Property a : numericAtts) {
            cAttributeMethod.addItem(a.getName());
        }
        for (Property m : numericMets) {
            cAttributeMethod.addItem(m.getName() + "()");
        }
        cAttributeMethod.setSelectedItem(null);
    }

    /**
     * @param s
     */
    private void addToExpression(String s) {
        if (m.canAdd(s)) {
            m.getExpression().add(s);
            refresh();
        }
    }

    /**
     * @param att
     */
    private void addToExpression(Property att) {
        if (m.canAdd(att)) {
            m.getExpression().add(att);
            refresh();
        }
    }

    /**
     *
     */
    private void updateButtonsState() {
        bAttributeMethod.setEnabled(true);
        bConstantValue.setEnabled(true);
        bRemove.setEnabled(true);
        bPlus.setEnabled(true);
        bMinus.setEnabled(true);
        bMult.setEnabled(true);
        bDiv.setEnabled(true);
        bMod.setEnabled(true);
        bParenthesesOpen.setEnabled(true);
        bParenthesesClose.setEnabled(true);
        if (m.getExpression().isEmpty()) {
            bRemove.setEnabled(false);
            bPlus.setEnabled(false);
            bMinus.setEnabled(false);
            bMult.setEnabled(false);
            bDiv.setEnabled(false);
            bMod.setEnabled(false);
            bParenthesesClose.setEnabled(false);
        } else {
            Object o = m.getExpression().get(m.getExpression().size() - 1);
            if (o instanceof Property) {
                bAttributeMethod.setEnabled(false);
                bConstantValue.setEnabled(false);
                bParenthesesOpen.setEnabled(false);
            } else {
                String s = o.toString();
                if (s.contains("(")) {
                    bPlus.setEnabled(false);
                    bMinus.setEnabled(false);
                    bMult.setEnabled(false);
                    bDiv.setEnabled(false);
                    bMod.setEnabled(false);
                    bParenthesesClose.setEnabled(false);
                } else if (s.contains(")")) {
                    bAttributeMethod.setEnabled(false);
                    bConstantValue.setEnabled(false);
                    bParenthesesOpen.setEnabled(false);
                } else if (s.contains("+") || s.contains("-") || s.contains("*") || s.contains("/") || s.contains("%")) {
                    bPlus.setEnabled(false);
                    bMinus.setEnabled(false);
                    bMult.setEnabled(false);
                    bDiv.setEnabled(false);
                    bMod.setEnabled(false);
                    bParenthesesClose.setEnabled(false);
                } else {
                    bAttributeMethod.setEnabled(false);
                    bConstantValue.setEnabled(false);
                    bParenthesesOpen.setEnabled(false);
                }
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pForm = new javax.swing.JPanel();
        pExpression = new javax.swing.JPanel();
        lExpression = new javax.swing.JLabel();
        pContent = new javax.swing.JPanel();
        pButtons = new javax.swing.JPanel();
        pOperator = new javax.swing.JPanel();
        bPlus = new javax.swing.JButton();
        bMinus = new javax.swing.JButton();
        bMult = new javax.swing.JButton();
        bDiv = new javax.swing.JButton();
        bMod = new javax.swing.JButton();
        bParenthesesOpen = new javax.swing.JButton();
        bParenthesesClose = new javax.swing.JButton();
        bRemove = new javax.swing.JButton();
        pAttributteConst = new javax.swing.JPanel();
        pWest = new javax.swing.JPanel();
        lAttributeMethod = new javax.swing.JLabel();
        lConstantValue = new javax.swing.JLabel();
        pCenter = new javax.swing.JPanel();
        pAttributeMethod = new javax.swing.JPanel();
        cAttributeMethod = new javax.swing.JComboBox<>();
        bAttributeMethod = new javax.swing.JButton();
        pConstantValue = new javax.swing.JPanel();
        bConstantValue = new javax.swing.JButton();
        tConstantValue = new javax.swing.JFormattedTextField();

        setLayout(new java.awt.BorderLayout());

        pForm.setLayout(new java.awt.BorderLayout());

        pExpression.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Expression", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.ABOVE_TOP));
        pExpression.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        pExpression.add(lExpression);

        pForm.add(pExpression, java.awt.BorderLayout.CENTER);

        pContent.setLayout(new java.awt.BorderLayout());

        pButtons.setLayout(new java.awt.BorderLayout());

        pOperator.setLayout(new java.awt.GridLayout(1, 0));

        bPlus.setText("+");
        bPlus.setMargin(new java.awt.Insets(0, 0, 0, 0));
        bPlus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPlusActionPerformed(evt);
            }
        });
        pOperator.add(bPlus);

        bMinus.setText("-");
        bMinus.setMargin(new java.awt.Insets(0, 0, 0, 0));
        bMinus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bMinusActionPerformed(evt);
            }
        });
        pOperator.add(bMinus);

        bMult.setText("*");
        bMult.setMargin(new java.awt.Insets(0, 0, 0, 0));
        bMult.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bMultActionPerformed(evt);
            }
        });
        pOperator.add(bMult);

        bDiv.setText("/");
        bDiv.setMargin(new java.awt.Insets(0, 0, 0, 0));
        bDiv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bDivActionPerformed(evt);
            }
        });
        pOperator.add(bDiv);

        bMod.setText("%");
        bMod.setMargin(new java.awt.Insets(0, 0, 0, 0));
        bMod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModActionPerformed(evt);
            }
        });
        pOperator.add(bMod);

        bParenthesesOpen.setText("(");
        bParenthesesOpen.setMargin(new java.awt.Insets(0, 0, 0, 0));
        bParenthesesOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bParenthesesOpenActionPerformed(evt);
            }
        });
        pOperator.add(bParenthesesOpen);

        bParenthesesClose.setText(")");
        bParenthesesClose.setMargin(new java.awt.Insets(0, 0, 0, 0));
        bParenthesesClose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bParenthesesCloseActionPerformed(evt);
            }
        });
        pOperator.add(bParenthesesClose);

        pButtons.add(pOperator, java.awt.BorderLayout.WEST);

        bRemove.setText("<-");
        bRemove.setMargin(new java.awt.Insets(0, 0, 0, 0));
        bRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bRemoveActionPerformed(evt);
            }
        });
        pButtons.add(bRemove, java.awt.BorderLayout.EAST);

        pContent.add(pButtons, java.awt.BorderLayout.SOUTH);

        pAttributteConst.setLayout(new java.awt.BorderLayout(10, 0));

        pWest.setLayout(new java.awt.GridLayout(2, 0));

        lAttributeMethod.setText("Attribute/Method");
        pWest.add(lAttributeMethod);

        lConstantValue.setText("Constant Value");
        pWest.add(lConstantValue);

        pAttributteConst.add(pWest, java.awt.BorderLayout.WEST);

        pCenter.setLayout(new java.awt.GridLayout(2, 0));

        pAttributeMethod.setLayout(new java.awt.BorderLayout());
        pAttributeMethod.add(cAttributeMethod, java.awt.BorderLayout.CENTER);

        bAttributeMethod.setText(">>");
        bAttributeMethod.setMargin(new java.awt.Insets(0, 0, 0, 0));
        bAttributeMethod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAttributeMethodActionPerformed(evt);
            }
        });
        pAttributeMethod.add(bAttributeMethod, java.awt.BorderLayout.EAST);

        pCenter.add(pAttributeMethod);

        pConstantValue.setLayout(new java.awt.BorderLayout());

        bConstantValue.setText(">>");
        bConstantValue.setMargin(new java.awt.Insets(0, 0, 0, 0));
        bConstantValue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bConstantValueActionPerformed(evt);
            }
        });
        pConstantValue.add(bConstantValue, java.awt.BorderLayout.EAST);

        tConstantValue.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0.######"))));
        pConstantValue.add(tConstantValue, java.awt.BorderLayout.CENTER);

        pCenter.add(pConstantValue);

        pAttributteConst.add(pCenter, java.awt.BorderLayout.CENTER);

        pContent.add(pAttributteConst, java.awt.BorderLayout.CENTER);

        pForm.add(pContent, java.awt.BorderLayout.SOUTH);

        add(pForm, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void bPlusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPlusActionPerformed
        addToExpression("+");
    }//GEN-LAST:event_bPlusActionPerformed

    private void bMinusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bMinusActionPerformed
        addToExpression("-");
    }//GEN-LAST:event_bMinusActionPerformed

    private void bMultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bMultActionPerformed
        addToExpression("*");
    }//GEN-LAST:event_bMultActionPerformed

    private void bDivActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bDivActionPerformed
        addToExpression("/");
    }//GEN-LAST:event_bDivActionPerformed

    private void bModActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModActionPerformed
        addToExpression("%");
    }//GEN-LAST:event_bModActionPerformed

    private void bParenthesesOpenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bParenthesesOpenActionPerformed
        addToExpression("(");
    }//GEN-LAST:event_bParenthesesOpenActionPerformed

    private void bParenthesesCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bParenthesesCloseActionPerformed
        addToExpression(")");
    }//GEN-LAST:event_bParenthesesCloseActionPerformed

    private void bConstantValueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bConstantValueActionPerformed
        if (!tConstantValue.getText().isEmpty()) {
            addToExpression("" + tConstantValue.getValue());
            tConstantValue.setText("");
        }
    }//GEN-LAST:event_bConstantValueActionPerformed

    private void bAttributeMethodActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAttributeMethodActionPerformed
        if (cAttributeMethod.getSelectedItem() != null) {
            Property att = classBean.getProperty(cAttributeMethod.getSelectedItem().toString());
            addToExpression(att);
            cAttributeMethod.setSelectedItem(null);
        }
    }//GEN-LAST:event_bAttributeMethodActionPerformed

    private void bRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bRemoveActionPerformed
        if (m.getExpression().size() > 0) {
            m.getExpression().remove(m.getExpression().size() - 1);
            refresh();
        }
    }//GEN-LAST:event_bRemoveActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAttributeMethod;
    private javax.swing.JButton bConstantValue;
    private javax.swing.JButton bDiv;
    private javax.swing.JButton bMinus;
    private javax.swing.JButton bMod;
    private javax.swing.JButton bMult;
    private javax.swing.JButton bParenthesesClose;
    private javax.swing.JButton bParenthesesOpen;
    private javax.swing.JButton bPlus;
    private javax.swing.JButton bRemove;
    private javax.swing.JComboBox<String> cAttributeMethod;
    private javax.swing.JLabel lAttributeMethod;
    private javax.swing.JLabel lConstantValue;
    private javax.swing.JLabel lExpression;
    private javax.swing.JPanel pAttributeMethod;
    private javax.swing.JPanel pAttributteConst;
    private javax.swing.JPanel pButtons;
    private javax.swing.JPanel pCenter;
    private javax.swing.JPanel pConstantValue;
    private javax.swing.JPanel pContent;
    private javax.swing.JPanel pExpression;
    private javax.swing.JPanel pForm;
    private javax.swing.JPanel pOperator;
    private javax.swing.JPanel pWest;
    private javax.swing.JFormattedTextField tConstantValue;
    // End of variables declaration//GEN-END:variables
}
