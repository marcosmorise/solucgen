package org.soluc.gen.generator;

import java.io.IOException;

/**
 *
 * @author marcos morise
 */
public final class ProjectGenerator {

    class CopyFile {
        public String source;
        public String destination;
    }

    private final org.soluc.gen.project.Project project;
    private final java.util.List<String> directories;
    private final java.util.List<CopyFile> generatedFiles;
    private final java.util.List<CopyFile> toCopyFiles;

    /**
     * Constructor
     *
     * @param project
     */
    public ProjectGenerator(org.soluc.gen.project.Project project) {
        this.project = project;
        this.directories = new java.util.ArrayList<>();
        this.generatedFiles = new java.util.ArrayList<>();
        this.toCopyFiles = new java.util.ArrayList<>();
    }

    /**
     * Constructor
     *
     * @param project
     */
    public ProjectGenerator(org.soluc.gen.project.Project project, String projectTemplate) {
        this(project);
        this.setProjectTemplate(projectTemplate);
    }
    
    /**
     * Copy a file from current JAR to destination folder
     *
     * @param source
     * @param destination
     * @throws java.io.IOException
     */
    private void copy(String source, String destination) throws java.io.IOException {
        java.io.InputStream resource = getClass().getClassLoader().getResourceAsStream(source);
        if (resource == null) {
            throw new java.io.IOException("Resource not found: " + source);
        }
        java.io.BufferedInputStream input = new java.io.BufferedInputStream(resource);
        java.io.BufferedOutputStream output = new java.io.BufferedOutputStream(new java.io.FileOutputStream(new java.io.File(destination)));
        byte[] buffer = new byte[1024];
        int length;
        while ((length = input.read(buffer)) > 0) {
            output.write(buffer, 0, length);
        }
        output.close();
        input.close();
    }
    
    /**
     * 
     * @param project
     * @param path
     * @param projectTemplate
     * @return
     * @throws IOException 
     */
    public static String projectGen(org.soluc.gen.project.Project project, String path, String projectTemplate) throws IOException {
        ProjectGenerator gen = new ProjectGenerator(project);
        projectTemplate = gen.setProjectTemplate(projectTemplate);
        gen.projectGen(path);
        return projectTemplate;
    }

    /**
     *
     * @param path
     * @throws java.io.IOException
     */
    public void projectGen(String path) throws IOException {
        //Create directories
        for (String directory : directories) {
            java.io.File dir = new java.io.File(path + "/" + directory);
            dir.mkdir();
        }

        //Copy resource files
        for (CopyFile copyFile : toCopyFiles) {
            copy(copyFile.source, path + "/" + copyFile.destination);
        }

        //Copy Generated code
        for (CopyFile copyFile : generatedFiles) {
            java.io.FileOutputStream fileGen;
            fileGen = new java.io.FileOutputStream(path + "/" + copyFile.destination);
            fileGen.write(copyFile.source.getBytes("UTF-8"));
            fileGen.close();
        }
    }

    /**
     *
     * @param projectTemplate
     * @return projectTemplate 
     */
    public String setProjectTemplate(String projectTemplate) {
        projectTemplate = projectTemplate.replaceAll("\n\\ *(?s)", "\n");
        //Create directories
        while (projectTemplate.contains("<@project.directory>")) {
            String directoriesGen = Generator.codeGen(project, null, Generator.getTagContent(projectTemplate.replaceAll("\n", "<@br/>"), "@project.directory"));
            this.directories.addAll(java.util.Arrays.asList(directoriesGen.split("\n")));
            projectTemplate = projectTemplate.replaceFirst("\\ *(?s)<@project.directory>.*?</@project.directory>", directoriesGen).replaceAll("\n\n", "\n");
        }

        //Create files
        while (projectTemplate.contains("<@project.files>")) {
            String files = "";
            for (String fileLine : Generator.codeGen(project, null, Generator.getTagContent(projectTemplate.replaceAll("\n", "<@br/>"), "@project.files")).split("\n")) {
                String[] fileParts = fileLine.split(" ");
                files += fileParts[0] + "\n";
                if (fileParts.length == 3) {
                    //Generate files
                    CopyFile copyFile = new CopyFile();
                    String codeGenTemplate = new java.util.Scanner(getClass().getResourceAsStream("/org/soluc/gen/templates/" + fileParts[1]), "UTF-8").useDelimiter("\\Z").next();
                    copyFile.destination = fileParts[0];
                    if (project.getName().equals(fileParts[2])) {
                        copyFile.source = org.soluc.gen.generator.Generator.codeGen(project, null, codeGenTemplate);
                    } else {
                        org.soluc.gen.project.ClassBean c = project.getClassBean(fileParts[2]);
                        copyFile.source = org.soluc.gen.generator.Generator.codeGen(project, c, codeGenTemplate);
                    }
                    this.generatedFiles.add(copyFile);
                } else if (fileParts.length == 2) {
                    //Copy files
                    CopyFile copyFile = new CopyFile();
                    copyFile.source = "org/soluc/gen/templates/" + fileParts[1];
                    copyFile.destination = fileParts[0];
                    this.toCopyFiles.add(copyFile);
                }
            }
            projectTemplate = projectTemplate.replaceFirst("\\ *(?s)<@project.files>.*?</@project.files>", files).replaceAll("\n\n", "\n");
        }

        return projectTemplate;
    }
}
